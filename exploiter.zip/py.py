import requests
import sys
import time
import re
import os
import subprocess
from bs4 import BeautifulSoup
from pystyle import Colors, Colorate, Write
from fake_useragent import UserAgent
import socket
from colorama import Fore, Style, init
from rich import print as cetak
from rich.panel import Panel as nel
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests, urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool

init(autoreset=True)

red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()

def clear():
    if sys.platform.startswith('linux'):
        os.system('clear')
    elif sys.platform.startswith('freebsd'):
        os.system('clear')
    else:
        os.system('cls')

headersx = {'User-Agent': UserAgent().random}

def gui():
    Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
    text = f""" 
[Fucking Society! - We go Hacked All] - GR33TZ 
[ @ ] MENU :
[ 1 ] KCFINDER SCANNER
[ 2 ] RFM SCANNER
[ 3 ] WP GHOST THEME SCANNER
[ 4 ] ROXY FILEMANAGER SCANNER
[ 5 ] GIT EXPOSE SCANNER
[ 6 ] WP INSTALL & WP SETUP SCANNER
[ 7 ] JQUERY FILE UPLOAD SCANNER
[ 8 ] COOKIE LOG SCANNER
[ 9 ] ALFA DATA SCANNER
[ 10 ] PHPUNIT SCANNER
[ 11 ] TELERIK SCANNER
[ 12 ] PATHEON SCANNER
[ 13 ] GITHUB SCANNER
[ 14 ] WP INTENSE SCANNER
[ 15 ] AJAX FILEMANAGER SCANNER
[ 16 ] WP SMTP SCANNER
[ 17 ] WP ORANGE THEMES SCANNER
[ 18 ] JCKEDITOR SCANNER
[ 19 ] SFTP CONFIG SCANNER
[ 20 ] WP EMELENTOR SCANNER
[ 21 ] MAILER SCANNER
[ 22 ] robots.txt SCANNER
[ 23 ] CVE-2023-28121 SCANNER
[ 24 ] CVE-2021-34621 SCANNER
[ 25 ] NGINX LOG SCANNER
[ 26 ] LARAVEL LOG SCANNER 
[ 27 ] PHP INFO SCANNER
[ 28 ] COMPOSER CONFIG SCANNER
[ 29 ] PASSWORD LOG SCANNER
[ 30 ] PARAMETERS .YML SCANNER
[ 31 ] DATABASE DUMP
[ 32 ] DEBUG RCE SCANNER
[ 33 ] LARAVEL FILEMANAGER SCANNER
[ 34 ] JOOMLA CONFIG SCANNER
[ 35 ] WORDPRESS CONFIG SCANNER
[ 36 ] LARAVEL ENV & REVSLIDER SCANNER (AUTO GET SSH, CPANNEL, SMTP, ETC...)
[ 37 ] CVE-2023-4666 SCANNER
[ 38 ] CVE-2023-5360 SCANNER
[ 39 ] CVE-2023-5504 SCANNER
[ 40 ] CVE-2023-6266 SCANNER
[ 41 ] CVE-2023-6063 SCANNER
[ 42 ] CVE-2023-4596 SCANNER
[ 43 ] Slims CMS Senayan Arbitary File Upload SCANNER
[ 44 ] KCFINDER FILE UPLOAD SCANNER
[ 45 ] FTP SYNC SCANNER
[ 46 ] CI_SESSION 
[ 47 ] CrackedCpWhmEtc
[ 48 ] ALL SCANNER"""

    for N, line in enumerate(text.split("\n")):
        print(Colorate.Horizontal(Colors.red_to_green, line, 1))
        time.sleep(0.05)
    Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)


def choose():
    init(autoreset=True)
    red = Fore.RED
    white = Fore.WHITE
    choose = int(input(f"\n\nroot@axvtech ~ # "))
    if choose == 1:
        os.system("py fitures/1.kcfinderScan/run.py")
    elif choose == 2:
        os.system("py fitures/2.rfmScan/run.py")
    elif choose == 3:
        os.system("py fitures/3.wpghostScan/run.py")
    elif choose == 4:
        os.system("py fitures/4.RFscanner/run.py")
    elif choose == 5:
        os.system("py fitures/5.gitexposeScan/run.py")
    elif choose == 6:
        os.system("py fitures/6.wpinstallScan/run.py")
    elif choose == 7:
        os.system("py fitures/7.jqueryFileScan/run.py")
    elif choose == 8:
        os.system("py fitures/8.CookieLogScan/run.py")
    elif choose == 9:
        os.system("py fitures/9.alfadataScan/run.py")
    elif choose == 10:
        os.system("py fitures/10.phpunit/run.py")
    elif choose == 11:
        os.system("py fitures/11.telerik/run.py")
    elif choose == 12:
        os.system("py fitures/12.patheon/run.py")
    elif choose == 13:
        os.system("py fitures/13.github/run.py")
    elif choose == 14:
        os.system("py fitures/14.wpintense/run.py")
    elif choose == 15:
        os.system("py fitures/15.ajaxfm/run.py")
    elif choose == 16:
        os.system("py fitures/16.wpsmtp/run.py")
    elif choose == 17:
        os.system("py fitures/17.wporange/run.py")
    elif choose == 18:
        os.system("py fitures/18.jckeditor/run.py")
    elif choose == 19:
        os.system("py fitures/19.sftpconfig/run.py")
    elif choose == 20:
        os.system("py fitures/20.wpelementor/run.py")
    elif choose == 21:
        os.system("py fitures/21.mailer/run.py")
    elif choose == 22:
        os.system("py fitures/22.robottxt/run.py")
    elif choose == 23:
        os.system("py fitures/23.Cve202328121/run.py")
    elif choose == 24:
        os.system("py fitures/24.Cve202134621/run.py")
    elif choose == 25:
        os.system("py fitures/25.ngixLog/run.py")
    elif choose == 26:
        os.system("py fitures/26.laravelLog/run.py")
    elif choose == 27:
        os.system("py fitures/27.phpinfo/run.py")
    elif choose == 28:
        os.system("py fitures/28.composer/run.py")
    elif choose == 29:
        os.system("py fitures/29.pwlog/run.py")
    elif choose == 30:
        os.system("py fitures/30.paramayml/run.py")
    elif choose == 31:
        os.system("py fitures/31.dbdump/run.py")
    elif choose == 32:
        os.system("py fitures/32.debugrce/run.py")
    elif choose == 33:
        os.system("py fitures/33.laravel/run.py")
    elif choose == 34:
        os.system("py fitures/34.joomfig/run.py")
    elif choose == 35:
        os.system("py fitures/35.wpconfig/run.py")
    elif choose == 36:
        os.system("py fitures/36.laravel/run.py")
    elif choose == 37:
        os.system("py fitures/37.CVE4666/run.py")
    elif choose == 38:
        os.system("py fitures/38.Cve5360/run.py")
    elif choose == 39:
        os.system("py fitures/39.CVE5504/run.py")
    elif choose == 40:
        os.system("py fitures/40.CVE6266/run.py")
    elif choose == 41:
        os.system("py fitures/41.CVE6063/run.py")
    elif choose == 42:
        os.system("py fitures/42.Cve20234596/run.py")
    elif choose == 43:
        os.system("py fitures/43.slimss/run.py")
    elif choose == 44:
        os.system("py fitures/44.kcfinderFile/run.py")
    elif choose == 45:
        os.system("py fitures/45.ftpsync/run.py")
    elif choose == 46:
        os.system("py fitures/46.ci_session/run.py")
    elif choose == 47:
        os.system("py fitures/47.CrackedCpWhmEtc/run.py")
    elif choose == 48:
        os.system("py fitures/48.scanall/run.py")
    else:
        print(f"{red}[{white}!{red}]{red} Option Not Available!")

if __name__ == "__main__":
    clear()
    gui()
    choose()

