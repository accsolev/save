import requests
import sys
import time
import re
import os
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')

def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : NGINX LOG SCANNER
# SAVED TO : results/nginxLog.txt"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
def nginxLog(domain):
	list = ['/nginx/log/', '/wp-content/nginx/log/', '/vagrant/nginx/log/', '/wp-includes/nginx/log/', '/home/nginx/log/', '/index/nginx/log/', '/wordpress/nginx/log/', '/backup/nginx/log/', '/app/nginx/log/']
	for list in list:
		try:
			domain = ''.join(domain)
			domain = domain.strip()
			domain = re.sub(r'https?://', '', domain)
			list = list.strip()
			req_nginxLog = requests.get(f"http://{domain}{list}", headers=headersx, timeout=7, verify=False).text
			if '/nginx/log' in req_nginxLog and "Parent Directory" in req_nginxLog:
				open("results/nginxLog.txt","a+").write(f"http://{domain}{list}\n")
				print(f"{blue}|- {white}http://{domain}{list} {yellow}| {green}Vuln!")
			else:
				print(f"{blue}|- {white}http://{domain}{list} {yellow}| {red}Not Vuln!")
		except:pass
def nginxLogInput():
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.map(nginxLog, domain)
 
 
if __name__ == "__main__":
            time.sleep(1)
            clear()
            gui()
            nginxLogInput()
        