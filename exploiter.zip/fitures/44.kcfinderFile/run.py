import requests
import sys
import time
import re
import os
from bs4 import BeautifulSoup
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')

def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : KCFINDER SCANNER
# SAVED TO : results/kcfinderFileUpload.txt"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
def kcfinderFile(domain):
	list = ['/assets/js/mylibs/kcfinder/browse.php', '/assets/js/kcfinder/upload.php', '/admin/assets/js/ckeditor/kcfinder/upload.php', '/ckeditor/plugins/kcfinder/upload.php', '/sftp-config.json', '/.vscode/sftp.json', '/kfinder/browse.php', '/ckeditor/kcfinder/browse.php', '/admin/kcfinder/browse.php', '/js/kcfinder/browse.php', '/Modules/ckeditor/kcfinder/browse.php', '/admin/ckeditor/kcfinder/browse.php', '/admin/js/kcfinder/browse.php', '/webboard/plugins/editors/kcfinder/browse.php', '/admin/lib/kcfinder/browse.php', '/klik/assets/kcfinder/browse.php', '/admin/assets/kcfinder/browse.php', '/templates/admin/js/kcfinder/browse.php', '/library/ckeditor/plugins/kcfinder/browse.php', '/modul/kcfinder/browse.php', '/asset/kcfinder/browse.php', '/master/kcfinder/browse.php', '/themes/js/kcfinder/browse.php', '/sys/kcfinder/browse.php', '/brostools/jquery/kcfinder/browse.ph', '/crm23/kcfinder/browse.php', '/web/assets/vendor/kcfinder/browse.php', '/brostools/jquery/kcfinder/browse.php', '/web/backend/plugins/bower_components/cke-editor/kcfinder/browse.php']
	for kcfinderlist in list:
		try:
			headersx = {'User-Agent': UserAgent().random}
			domain = ''.join(domain)
			domain = domain.strip()
			domain = re.sub(r'https?://', '', domain)
			req_kcfinder = requests.get(f"http://{domain}{kcfinderlist}", headers=headersx, timeout=10, verify=False).text
			if '<title>KCFinder: /' in req_kcfinder and '>Upload</' in req_kcfinder:
				open("results/kcfinderFileUpload.txt","a+").write(f"http://{domain}{kcfinderlist}\n")
				print(f"{blue}|- {white}http://{domain}{kcfinderlist} {yellow}| {green}Vuln!")
			else:
				print(f"{blue}|- {white}http://{domain}{kcfinderlist} {yellow}| {red}Not Vuln!")
		except:pass
def kcfinderrFile():
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.map(kcfinderFile, domain)
 
if __name__ == "__main__":
            time.sleep(1)
            clear()
            gui()
            kcfinderrFile()
        