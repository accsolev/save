import requests
import sys
import time
import re
import os
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')
def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : CVE-2023-28121 SCANNER
# SAVED TO : results/CVE-2023-28121.txt"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
def Cve202328121(domain):
	try:
		headersx = {'User-Agent': UserAgent().random}
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		req_Cve202328121 = requests.get(f'http://{domain}/wp-content/plugins/woocommerce-payments/readme.txt', headers=headersx, timeout=7, verify=False).text
		if "WooCommerce Payments" in req_Cve202328121 and 'Description' in req_Cve202328121:
			versi = re.findall('\sStable tag: (.*?)\s', req_Cve202328121)
			versi = ''.join(versi)
			if versi <= '5.7.1':
				open("results/CVE-2023-28121.txt","a+").write(f'http://{domain}/wp-content/plugins/woocommerce-payments/readme.txt\n')
				print(f"{blue}|- {white}http://{domain} {yellow}| {green}Found CVE-2023-28121")
			else:pass
		else:
			print(f"{blue}|- {white}http://{domain} {yellow}| {red}Not Vuln!")
	except:pass
def Cve202328121Input():
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.map(Cve202328121, domain)
 
if __name__ == "__main__":
            time.sleep(1)
            clear()
            gui()
            Cve202328121Input()
        