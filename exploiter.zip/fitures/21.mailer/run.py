import requests
import sys
import time
import re
import os
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')

def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : MAILER SCANNER
# SAVED TO : results/mailer.txt"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
def mailer(domain):
	list = ['/leaf.php', '/alexusMailer.php','/wordpress/leaf.php', '/wp-includes/24.php','/wp-includes/cof.php','/images/pushy.php','/images/mscr.php','/.well-known/owl.php','/images/1260787_20061053.jpg.php','/.well-known/leaf.php','/wp-includes/js/tinymce/plugins/media/alexusMailer.php', '/wp-content/leaf.php', '/wp-includes/leaf.php','/.well-known/acme-challenge/leaf.php','/images/index2.php','/wp-content/uploads/2022/02/leaf.php','/wp-content/uploads/bulk.php','/wp-content/uploads/2023_old/11/send.php','/.well-known/acme-challenge/jaltax.php']
	for list in list:
		try:
			req_mailer = requests.get(f"http://{domain}{list}", headers=headersx, timeout=10, verify=False).text
			if 'Leaf PHPMailer' in req_mailer or ">alexusMailer 2.0<" in req_mailer or '>Owl PHPMailer' in req_mailer or 'Mailer V1.0' in req_mailer or 'PHP Mailer Script' in req_mailer or 'Inbox Mass Mailer' in req_mailer or 'n30Mailer' in req_mailer:
				open("results/mailer.txt","a+").write(f"http://{domain}{list}\n")
				print(f"{blue}|- {white}http://{domain}{list} {yellow}| {green}Vuln!")
			else:
				print(f"{blue}|- {white}http://{domain}{list} {yellow}| {red}Not Vuln!")
		except:pass
def mailerInput():
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.map(mailer, domain)
 
if __name__ == "__main__":
            time.sleep(1)
            clear()
            gui()
            mailerInput()
        