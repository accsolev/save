import requests
import sys
import time
import re
import os
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')

def gui_kcfinder():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : KCFINDER SCANNER
# SAVED TO : results/kcfinder.txt"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
def kcfinder(domain):
	list = [
            'ckeditor/kcfinder/upload.php', 
            'assets/js/kcfinder/upload.php',
            'kcfinder/upload.php',
            'kcfinder/upload.php', 
            'assets/kcfinder/upload.php', 
            'webboard/plugins/editors/kcfinder/upload.php', 
            'admin/editor/kcfinder/upload.php', 
            'ckeditor/plugins/kcfinder/upload.php', 
            'admin-panel/vendor/kcfinder/upload.php', 
            'assets/admin/kcfinder/upload.php',
            'assets/plugin/kcfinder/upload.php', 
            'plugins/kcfinder/upload.php', 
            'admin/kcfinder/upload.php', 
            'vendor/kcfinder/upload.php', 
            'painel/kcfinder/upload.php', 
            'admin/assets/js/ckeditor/kcfinder/upload.php',
            'panel/kcfinder/upload.php', 
            'js/kcfinder/upload.php',
            'yonetim/engine/ckeditor/kcfinder/upload.php', 
            'assets/admin/js/kcfinder/upload.php', 
            'js/kcfinder/upload.php',
            'upload/kcfinder/upload.php',
            'site/plugins/kcfinder/upload.php',
            'assets/js/kcfinder/upload.php',
            'app/libraries/kcfinder/upload.php',
            'modules/kcfinder/upload.php',
            'lib/kcfinder/upload.php',
            'uploads/kcfinder/upload.php',
            'storage/app/kcfinder/upload.php',
            'inc/kcfinder/upload.php',
            'assets/ckeditor/kcfinder/upload.php',
            'resources/kcfinder/upload.php',
            'modules/admin/editor/kcfinder/upload.php',
            'system/kcfinder/upload.php',
            'assets/admin/plugins/kcfinder/upload.php',
            'en/kcfinder/upload.php',
            'plugin/ckeditor/kcfinder/upload.php',
            'data/kcfinder/upload.php',
            'core/kcfinder/upload.php',
            'files/kcfinder/upload.php',
            'admin/public/kcfinder/upload.php',
            'media/kcfinder/upload.php',
            'modules/ckeditor/kcfinder/upload.php',
            'plugin/kcfinder/upload.php',
            'system/libraries/kcfinder/upload.php',
            'foo/kcfinder/upload.php',
            'bar/kcfinder/upload.php',
            'test/kcfinder/upload.php',
            'tmp/kcfinder/upload.php',
            'secret/kcfinder/upload.php',
            'logs/kcfinder/upload.php',
            'config/kcfinder/upload.php',
            'private/kcfinder/upload.php',
            'data/uploads/kcfinder/upload.php',
            'images/kcfinder/upload.php',
            'uploads/cache/kcfinder/upload.php',
            'assets/css/kcfinder/upload.php',
            'upload/images/kcfinder/upload.php',
            'img/kcfinder/upload.php',
            'filemanager/kcfinder/upload.php',
            'storage/kcfinder/upload.php',
            'uploads/files/kcfinder/upload.php',
            'gallery/kcfinder/upload.php',
            'vendor/assets/kcfinder/upload.php',
            'uploads/images/kcfinder/upload.php',
            'files/docs/kcfinder/upload.php',
            'config/config.kcfinder/upload.php',
            'assets/kcfinder/src/',
            'data/files/kcfinder/upload.php',
            'includes/kcfinder/upload.php',
            'resources/views/kcfinder/upload.php',
            'upload/files/kcfinder/upload.php',
            'cache/kcfinder/upload.php',
            'uploads/uploadfiles/kcfinder/upload.php',
            'library/kcfinder/upload.php',
            'system/assets/kcfinder/upload.php',
            'js/ckeditor/kcfinder/upload.php',
            'data/upload/kcfinder/upload.php',
            'tmp/cache/kcfinder/upload.php',
            'lib/ckeditor/kcfinder/upload.php',
            'data/file/kcfinder/upload.php',
            'js/libs/kcfinder/upload.php',
            'files/data/kcfinder/upload.php',
            'css/kcfinder/upload.php',
            'plugins/ckeditor/kcfinder/upload.php',
            'upload/images/uploads/kcfinder/upload.php',
            'site/ckeditor/kcfinder/upload.php',
            'assets/css/admin/kcfinder/upload.php',
            'uploads/uploads/kcfinder/upload.php',
            'public/kcfinder/upload.php',
            'upload/uploads/kcfinder/upload.php',
            'cache/images/kcfinder/upload.php',
            'admin/kcfinder/upload.php',
            'app/assets/kcfinder/upload.php',
            'assets/cms/kcfinder/upload.php',
            'uploads/uploads/uploads/kcfinder/upload.php',
            'css/admin/kcfinder/upload.php',
            'uploads/files/files/kcfinder/upload.php',
            'upload/images/images/kcfinder/upload.php',
            'uploads/data/kcfinder/upload.php',
            'uploads/images/upload/kcfinder/upload.php',
            'uploads/images/files/kcfinder/upload.php',
            'uploads/data/files/kcfinder/upload.php',
            'ckeditor/kcfinder/upload.phpkcfinder/upload.php',
            'assets/kcfinder/upload.phpckeditor/',
            'uploads/upload/kcfinder/upload.php',
            'fileuploads/kcfinder/upload.php',
            'uploads/images/images/uploads/kcfinder/upload.php',
            'uploads/upload/upload/kcfinder/upload.php',
            'uploads/files/uploads/kcfinder/upload.php',
            'assets/ckeditor/plugins/kcfinder/upload.php',
            'ckeditor/plugins/kcfinder/upload.php',
            'uploads/images/upload/images/kcfinder/upload.php',
            'uploads/images/files/uploads/kcfinder/upload.php',
            'uploads/images/uploadfiles/kcfinder/upload.php',
            'uploads/files/upload/images/kcfinder/upload.php',
            'uploads/images/files/upload/kcfinder/upload.php',
        ]
	for kcfinderlist in list:
		try:
			headersx = {'User-Agent': UserAgent().random}
			domain = ''.join(domain)
			domain = domain.strip()
			domain = re.sub(r'https?://', '', domain)
			req_kcfinder = requests.get(f"http://{domain}/{kcfinderlist}", headers=headersx, timeout=7, verify=False).text
			if 'kc_FCKeditor' in req_kcfinder and 'alert("Unknown error");' in req_kcfinder:
				open("results/kcfinder.txt","a+").write(f"http://{domain}{kcfinderlist}\n")
				print(f"{blue}|- {white}http://{domain}{kcfinderlist} {yellow}| {green}Vuln!")
			else:
				print(f"{blue}|- {white}http://{domain}{kcfinderlist} {yellow}| {red}Not Vuln!")
		except:pass
def kcfinderr():
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.map(kcfinder, domain)
 
 
if __name__ == "__main__":
            clear()
            gui_kcfinder()
            kcfinderr()
