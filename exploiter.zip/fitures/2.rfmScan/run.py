import requests
import sys
import time
import re
import os
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()

def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')


############ RFM
def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : RFM SCANNER
# LAST UPDATED : 13-03-2024
# PATH : 235
# SAVED TO : results/rfm.txt"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
def rfm(domain):
	list = ['/filemanager/dialog.php', '/admin/filemanager/dialog.php', '/media/upload/filemanager/dialog.php', '/plugins/filemanager/dialog.php', '/plugins/tinymce/plugins/filemanager/dialog.php', '/media/upload/filemanager/filemanager/dialog.php', '/filemanager/filemanager/dialog.php', '/admin/filemanager/filemanager/dialog.php', '/admin/javascripts/tinymce/filemanager/dialog.php', '/admin/javascripts/tinymce/filemanager/filemanager/dialog.php', '/admin/assets/tinymce/filemanager/dialog.php', '/admin/assets/tinymce/filemanager/filemanager/dialog.php', '/admin/js/filemanager/dialog.php', '/admin/js/filemanager/filemanager/dialog.php', '/admin/scripts/filemanager/dialog.php', '/admin/scripts/filemanager/filemanager/dialog.php', '/js/tinymce/plugins/filemanager/dialog.php', '/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/js/tinymce/filemanager/dialog.php', '/js/tinymce/filemanager/filemanager/dialog.php', '/js/filemanager/dialog.php', '/assets/plugins/filemanager/dialog.php', '/assets/filemanager/dialog.php', '/media/assets/filemanager/dialog.php', '/assets/filemanager/dialog.php?akey=GantiKunciDesa', '/api/vendor/filemanager/dialog.php', '/vendor/filemanager/dialog.php', '/contents/filemanager/dialog.php', '/js/filemanager/filemanager/dialog.php', '/tinymce/js/tinymce/plugins/filemanager/dialog.php', '/tinymce/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/tinymce/js/filemanager/dialog.php', '/tinymce/js/filemanager/filemanager/dialog.php', '/tinymce/filemanager/dialog.php', '/tinymce/filemanager/filemanager/dialog.php', '/assets/filemanager/filemanager/dialog.php', '/assets/backend/js/plugins/filemanager/dialog.php', '/assets/backend/js/plugins/filemanager/filemanager/dialog.php', '/assets/tinymce/filemanager/dialog.php', '/assets/tinymce/filemanager/filemanager/dialog.php', '/assets/plugins/filemanager/filemanager/dialog.php', '/assets/js/plugins/filemanager/dialog.php', '/assets/js/plugins/filemanager/filemanager/dialog.php', '/assets/javascripts/plugins/filemanager/dialog.php', '/assets/javascripts/plugins/filemanager/filemanager/dialog.php', '/assets/js/tinymce/filemanager/dialog.php', '/assets/js/tinymce/filemanager/filemanager/dialog.php', '/assets/javascripts/tinymce/filemanager/dialog.php', '/assets/javascripts/tinymce/filemanager/filemanager/dialog.php', '/www/filemanager/dialog.php', '/www/filemanager/filemanager/dialog.php', '/scripts/filemanager/dialog.php', '/scripts/filemanager/filemanager/dialog.php', '/scripts/tinymce/filemanager/dialog.php', '/scripts/tinymce/filemanager/filemanager/dialog.php', '/scripts/plugins/filemanager/dialog.php', '/scripts/plugins/filemanager/filemanager/dialog.php', '/scripts/plugins/tinymce/filemanager/dialog.php', '/scripts/plugins/tinymce/filemanager/filemanager/dialog.php', '/public/scripts/tinymce/filemanager/dialog.php', '/public/scripts/tinymce/filemanager/filemanager/dialog.php', '/public/javascripts/tinymce/filemanager/dialog.php', '/public/javascripts/tinymce/filemanager/filemanager/dialog.php', '/public/js/tinymce/plugins/filemanager/dialog.php', '/public/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/public/filemanager/dialog.php', '/public/filemanager/filemanager/dialog.php', '/public/js/filemanager/dialog.php', '/public/js/filemanager/filemanager/dialog.php', '/public/javascripts/filemanager/dialog.php', '/public/javascripts/filemanager/filemanager/dialog.php', '/public/assets/tinymce/filemanager/dialog.php', '/public/assets/tinymce/filemanager/filemanager/dialog.php', '/public/tinymce/filemanager/dialog.php', '/public/tinymce/filemanager/filemanager/dialog.php', '/assets/file_manager/filemanager/dialog.php', '/assets/js/file_manager/filemanager/dialog.php', '/assets/js/tinymce/file_manager/filemanager/dialog.php', '/assets/js/tinymce/plugins/file_manager/filemanager/dialog.php', '/assets/js/tinymce/plugins/file_manager/dialog.php', '/file_manager/dialog.php', '/assets/file_manager/dialog.php', '/assets/tinymce/file_manager/dialog.php', '/assets/tinymce/plugins/file_manager/dialog.php', '/system/plugin/filemanager/dialog.php', '/system/filemanager/dialog.php', '/system/js/plugin/filemanager/dialog.php', '/system/js/plugin/filemanager/filemanager/dialog.php', '/system/js/plugins/filemanager/dialog.php', '/system/js/plugins/filemanager/filemanager/ dialog.php', '/system/js/plugins/tinymce/filemanager/dialog.php', '/system/js/plugin/tinymce/filemanager/dialog.php', '/fmanager/filemanager/dialog.php', '/fmanager/filemanager/filemanager/dialog.php', '/storage/scripts/tinymce/filemanager/dialog.php', '/storage/scripts/tinymce/filemanager/filemanager/dialog.php', '/storage/javascripts/tinymce/filemanager/dialog.php', '/storage/javascripts/tinymce/filemanager/filemanager/dialog.php', '/storage/js/tinymce/plugins/filemanager/dialog.php', '/storage/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/storage/filemanager/dialog.php', '/storage/filemanager/filemanager/dialog.php', '/storage/js/filemanager/dialog.php', '/storage/js/filemanager/filemanager/dialog.php', '/storage/javascripts/filemanager/dialog.php', '/storage/javascripts/filemanager/filemanager/dialog.php', '/storage/assets/tinymce/filemanager/dialog.php', '/storage/assets/tinymce/filemanager/filemanager/dialog.php', '/storage/tinymce/filemanager/dialog.php', '/storage/tinymce/filemanager/filemanager/dialog.php', '/vendor/scripts/tinymce/filemanager/dialog.php', '/vendor/scripts/tinymce/filemanager/filemanager/dialog.php', '/vendor/javascripts/tinymce/filemanager/dialog.php', '/vendor/javascripts/tinymce/filemanager/filemanager/dialog.php', '/vendor/js/tinymce/plugins/filemanager/dialog.php', '/vendor/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/vendor/filemanager/filemanager/dialog.php', '/vendor/js/filemanager/dialog.php', '/vendor/js/filemanager/filemanager/dialog.php', '/vendor/javascripts/filemanager/dialog.php', '/vendor/javascripts/filemanager/filemanager/dialog.php', '/vendor/assets/tinymce/filemanager/dialog.php', '/vendor/assets/tinymce/filemanager/filemanager/dialog.php', '/vendor/tinymce/filemanager/dialog.php', '/vendor/tinymce/filemanager/filemanager/dialog.php', '/adm/scripts/tinymce/filemanager/dialog.php', '/adm/scripts/tinymce/filemanager/filemanager/dialog.php', '/adm/javascripts/tinymce/filemanager/dialog.php', '/adm/javascripts/tinymce/filemanager/filemanager/dialog.php', '/adm/js/tinymce/plugins/filemanager/dialog.php', '/adm/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/adm/filemanager/dialog.php', '/adm/filemanager/filemanager/dialog.php', '/adm/js/filemanager/dialog.php', '/adm/js/filemanager/filemanager/dialog.php', '/adm/javascripts/filemanager/dialog.php', '/adm/javascripts/filemanager/filemanager/dialog.php', '/adm/assets/tinymce/filemanager/dialog.php', '/adm/assets/tinymce/filemanager/filemanager/dialog.php', '/adm/tinymce/filemanager/dialog.php', '/adm/tinymce/filemanager/filemanager/dialog.php', '/administrator/scripts/tinymce/filemanager/dialog.php', '/administrator/scripts/tinymce/filemanager/filemanager/dialog.php', '/administrator/javascripts/tinymce/filemanager/dialog.php', '/administrator/javascripts/tinymce/filemanager/filemanager/dialog.php', '/administrator/js/tinymce/plugins/filemanager/dialog.php', '/administrator/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/administrator/filemanager/dialog.php', '/administrator/filemanager/filemanager/dialog.php', '/administrator/js/filemanager/dialog.php', '/administrator/js/filemanager/filemanager/dialog.php', '/administrator/javascripts/filemanager/dialog.php', '/administrator/javascripts/filemanager/filemanager/dialog.php', '/administrator/assets/tinymce/filemanager/dialog.php', '/administrator/assets/tinymce/filemanager/filemanager/dialog.php', '/administrator/tinymce/filemanager/dialog.php', '/administrator/tinymce/filemanager/filemanager/dialog.php', '/lib/scripts/tinymce/filemanager/dialog.php', '/lib/scripts/tinymce/filemanager/filemanager/dialog.php', '/lib/javascripts/tinymce/filemanager/dialog.php', '/lib/javascripts/tinymce/filemanager/filemanager/dialog.php', '/lib/js/tinymce/plugins/filemanager/dialog.php', '/lib/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/lib/filemanager/dialog.php', '/lib/filemanager/filemanager/dialog.php', '/lib/js/filemanager/dialog.php', '/lib/js/filemanager/filemanager/dialog.php', '/lib/javascripts/filemanager/dialog.php', '/lib/javascripts/filemanager/filemanager/dialog.php', '/lib/assets/tinymce/filemanager/dialog.php', '/lib/assets/tinymce/filemanager/filemanager/dialog.php', '/lib/tinymce/filemanager/dialog.php', '/lib/tinymce/filemanager/filemanager/dialog.php', '/site/scripts/tinymce/filemanager/dialog.php', '/site/scripts/tinymce/filemanager/filemanager/dialog.php', '/site/javascripts/tinymce/filemanager/dialog.php', '/site/javascripts/tinymce/filemanager/filemanager/dialog.php', '/site/js/tinymce/plugins/filemanager/dialog.php', '/site/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/site/filemanager/dialog.php', '/site/filemanager/filemanager/dialog.php', '/site/js/filemanager/dialog.php', '/site/js/filemanager/filemanager/dialog.php', '/site/javascripts/filemanager/dialog.php', '/site/javascripts/filemanager/filemanager/dialog.php', '/site/assets/tinymce/filemanager/dialog.php', '/site/assets/tinymce/filemanager/filemanager/dialog.php', '/site/tinymce/filemanager/dialog.php', '/site/tinymce/filemanager/filemanager/dialog.php', '/web/scripts/tinymce/filemanager/dialog.php', '/web/scripts/tinymce/filemanager/filemanager/dialog.php', '/web/javascripts/tinymce/filemanager/dialog.php', '/web/javascripts/tinymce/filemanager/filemanager/dialog.php', '/web/js/tinymce/plugins/filemanager/dialog.php', '/web/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/web/filemanager/dialog.php', '/web/filemanager/filemanager/dialog.php', '/web/js/filemanager/dialog.php', '/web/js/filemanager/filemanager/dialog.php', '/web/javascripts/filemanager/dialog.php', '/web/javascripts/filemanager/filemanager/dialog.php', '/web/assets/tinymce/filemanager/dialog.php', '/web/assets/tinymce/filemanager/filemanager/dialog.php', '/web/tinymce/filemanager/dialog.php', '/web/tinymce/filemanager/filemanager/dialog.php', '/webroot/scripts/tinymce/filemanager/dialog.php', '/webroot/scripts/tinymce/filemanager/filemanager/dialog.php', '/webroot/javascripts/tinymce/filemanager/dialog.php', '/webroot/javascripts/tinymce/filemanager/filemanager/dialog.php', '/webroot/js/tinymce/plugins/filemanager/dialog.php', '/webroot/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/webroot/filemanager/dialog.php', '/webroot/filemanager/filemanager/dialog.php', '/webroot/js/filemanager/dialog.php', '/webroot/js/filemanager/filemanager/dialog.php', '/webroot/javascripts/filemanager/dialog.php', '/webroot/javascripts/filemanager/filemanager/dialog.php', '/webroot/assets/tinymce/filemanager/dialog.php', '/webroot/assets/tinymce/filemanager/filemanager/dialog.php', '/webroot/tinymce/filemanager/dialog.php', '/webroot/tinymce/filemanager/filemanager/dialog.php', '/www/scripts/tinymce/filemanager/dialog.php', '/www/scripts/tinymce/filemanager/filemanager/dialog.php', '/www/javascripts/tinymce/filemanager/dialog.php', '/www/javascripts/tinymce/filemanager/filemanager/dialog.php', '/www/js/tinymce/plugins/filemanager/dialog.php', '/www/js/tinymce/plugins/filemanager/filemanager/dialog.php', '/www/js/filemanager/dialog.php', '/www/js/filemanager/filemanager/dialog.php', '/www/javascripts/filemanager/dialog.php', '/www/javascripts/filemanager/filemanager/dialog.php', '/www/assets/tinymce/filemanager/dialog.php', '/www/assets/tinymce/filemanager/filemanager/dialog.php', '/www/tinymce/filemanager/dialog.php', '/www/tinymce/filemanager/filemanager/dialog.php']
	for rfm in list:
		try:
			headersx = {'User-Agent': UserAgent().random}
			domain = ''.join(domain)
			domain = domain.strip()
			domain = re.sub(r'https?://', '', domain)
			rfm = rfm.strip()
			req_rfm = requests.get(f"http://{domain}{rfm}", headers=headersx, timeout=7, verify=False).text
			if 'Responsive FileManager' in req_rfm:
				open("results/rfm.txt","a+").write(f"http://{domain}{rfm}\n")
				print(f"{blue}|- {white}http://{domain}{rfm} {yellow}| {green}Vuln!")
			else:
				print(f"{blue}|- {white}http://{domain}{rfm} {yellow}| {red}Not Vuln!")
		except:pass
def rfmInput():
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.map(rfm, domain)
 
 
if __name__ == "__main__":
            clear()
            gui()
            rfmInput()
