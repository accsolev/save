import requests
import sys
import time
import re
import os
from bs4 import BeautifulSoup
from pystyle import Colors,Colorate,Write
from fake_useragent import UserAgent
from colorama import Fore,Style,init
from rich import print as cetak
from multiprocessing.dummy import Pool, Lock, Semaphore
import requests,urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from multiprocessing import Pool
init(autoreset=True)
headersx = {'User-Agent': UserAgent().random}
red = Fore.RED
green = Fore.GREEN 
yellow = Fore.YELLOW
white = Fore.WHITE
blue = Fore.BLUE
MAX_THREADS = 50
thread_semaphore = Semaphore(MAX_THREADS)
thread_lock = Lock()
def clear():
	if sys.platform.startswith('linux'):
		os.system('clear')
	elif sys.platform.startswith('freebsd'):
		os.system('clear')
	else:
		os.system('cls')

def gui():
	Write.Print("─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
	text = f""" 
 █████╗ ██╗  ██╗██╗   ██╗    ██████╗  ██████╗ ████████╗
██╔══██╗╚██╗██╔╝██║   ██║    ██╔══██╗██╔═══██╗╚══██╔══╝
███████║ ╚███╔╝ ██║   ██║    ██████╔╝██║   ██║   ██║   
██╔══██║ ██╔██╗ ╚██╗ ██╔╝    ██╔══██╗██║   ██║   ██║   
██║  ██║██╔╝ ██╗ ╚████╔╝     ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝      ╚═════╝  ╚═════╝    ╚═╝  

# CREATED BY : t.me/AXVDIGITAL
# TOOLS NAME : CVE-2023-4596 SCANNER
# SAVED TO : results/CVE-2023-4596.txt"""
	for N, line in enumerate(text.split("\n")):
		print(Colorate.Horizontal(Colors.red_to_green, line, 1))
		time.sleep(0.05)
	Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n\n", Colors.blue_to_purple, interval=0.01)
def Cve20234596(domain):
	try:
		headersx = {'User-Agent': UserAgent().random}
		domain = ''.join(domain)
		domain = domain.strip()
		domain = re.sub(r'https?://', '', domain)
		reqs = requests.get(f"http://{domain}/wp-content/plugins/forminator/readme.txt", headers=headersx, timeout=7, verify=False)
		soup = BeautifulSoup(reqs.text, 'html.parser')
		soup = str(soup)
		version = re.search(r'Stable tag: (\d+).(\d+).(\d+)', soup)
		if version:
			v = version.group()
			x = v.split(": ")
			xx = x[1].split('.')
			x2 = int(xx[0])
			x3 = int(xx[1])
			x4 = int(xx[2])
			if x2 == 1 and x3 == 24 and x4 == 6:
				open("results/CVE-2023-4596.txt","a+").write(f"http://{domain}/wp-content/plugins/forminator/readme.txt\n")
				print(f"|- {white}http://{domain} {yellow}| {green}Vuln!")
			else:print(f"|- {white}http://{domain} {yellow}| {red}Not Vuln!")
		else:
			print(f"|- {white}http://{domain} {yellow}| {red}Not Vuln!")
	except:pass
def Cve20234596Input():
	domain = open(input(f"{red}[{white}#{red}]{white} LIST SITE : ")).readlines()
	thr = int(input(f"{red}[{white}#{red}]{white} THREADS (Max 50): "))
	ThreadPool = Pool(thr)
	ThreadPool.map(Cve20234596, domain)
 
if __name__ == "__main__":
            time.sleep(1)
            clear()
            gui()
            Cve20234596Input()
        else:print(f"\t{red}[!] {white}IP NOT FOUND!")
    except:pass